---
title: "Python built-ins reference"
source: https://docs.python.org/3.14/builtins/index.html
---

# Python built-ins reference

Python comes with a number of built-in functions and classes.

The built-in classes include data types that would normally be considered part of the “core” of a language, such as numbers and lists. For these types, the Python language core defines the form of literals and places some constraints on their semantics, but does not fully define the semantics.

The built-ins also include functions and exceptions — objects that can be used by all Python code without the need of an [`import`](../reference/simple_stmts.md#import) statement. Some of these are defined by the core language, but many are not essential for the core semantics and are only described here.

> **See also:**
>
> In addition to the built-ins, Python provides an extensive importable standard library, see [The Python standard library](../library/index.md#library-index).

- [Built-in Types](stdtypes.md)
  - [Truth Value Testing](stdtypes.md#truth-value-testing)
  - [Boolean Operations — `and`, `or`, `not`](stdtypes.md#boolean-operations-and-or-not)
  - [Comparisons](stdtypes.md#comparisons)
  - [Numeric Types — `int`, `float`, `complex`](stdtypes.md#numeric-types-int-float-complex)
  - [Boolean Type - `bool`](stdtypes.md#boolean-type-bool)
  - [Iterator Types](stdtypes.md#iterator-types)
  - [Sequence Types — `list`, `tuple`, `range`](stdtypes.md#sequence-types-list-tuple-range)
  - [Text and Binary Sequence Type Methods Summary](stdtypes.md#text-and-binary-sequence-type-methods-summary)
  - [Text Sequence Type — `str`](stdtypes.md#text-sequence-type-str)
  - [Binary Sequence Types — `bytes`, `bytearray`, `memoryview`](stdtypes.md#binary-sequence-types-bytes-bytearray-memoryview)
  - [Set Types — `set`, `frozenset`](stdtypes.md#set-types-set-frozenset)
  - [Mapping Types — `dict`](stdtypes.md#mapping-types-dict)
  - [Context Manager Types](stdtypes.md#context-manager-types)
  - [Type Annotation Types — Generic Alias, Union](stdtypes.md#type-annotation-types-generic-alias-union)
  - [Other Built-in Types](stdtypes.md#other-built-in-types)
  - [Special Attributes](stdtypes.md#special-attributes)
  - [Integer string conversion length limitation](stdtypes.md#integer-string-conversion-length-limitation)
- [Built-in Constants](constants.md)
  - [Constants added by the `site` module](constants.md#constants-added-by-the-site-module)
- [Built-in Functions](functions.md)
- [Built-in Exceptions](exceptions.md)
  - [Exception context](exceptions.md#exception-context)
  - [Inheriting from built-in exceptions](exceptions.md#inheriting-from-built-in-exceptions)
  - [Base classes](exceptions.md#base-classes)
  - [Concrete exceptions](exceptions.md#concrete-exceptions)
  - [Warnings](exceptions.md#warnings)
  - [Exception groups](exceptions.md#exception-groups)
  - [Exception hierarchy](exceptions.md#exception-hierarchy)
- [Thread Safety Guarantees](threadsafety.md)
  - [Thread safety levels](threadsafety.md#thread-safety-levels)
  - [Thread safety for list objects](threadsafety.md#thread-safety-for-list-objects)
  - [Thread safety for dict objects](threadsafety.md#thread-safety-for-dict-objects)
  - [Thread safety for set objects](threadsafety.md#thread-safety-for-set-objects)
  - [Thread safety for bytearray objects](threadsafety.md#thread-safety-for-bytearray-objects)
  - [Thread safety for memoryview objects](threadsafety.md#thread-safety-for-memoryview-objects)
- [Time complexity of operations on built-in types](time-complexity.md)
  - [`list`](time-complexity.md#list)
  - [`tuple`](time-complexity.md#tuple)
  - [`dict`](time-complexity.md#dict)
  - [`set`, `frozenset`](time-complexity.md#set-frozenset)
  - [`str`, `bytes`, `bytearray`](time-complexity.md#str-bytes-bytearray)
  - [`memoryview`](time-complexity.md#memoryview)
  - [`range`](time-complexity.md#range)
  - [Notes](time-complexity.md#notes)
