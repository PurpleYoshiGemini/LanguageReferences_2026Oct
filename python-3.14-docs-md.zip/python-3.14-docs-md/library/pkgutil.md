---
title: "pkgutil — Package extension utility"
source: https://docs.python.org/3.14/library/pkgutil.html
---

# `pkgutil` — Package extension utility

**Source code:** [Lib/pkgutil.py](https://github.com/python/cpython/tree/3.14/Lib/pkgutil.py)

------------------------------------------------------------------------

This module provides utilities for the import system, in particular package support.

**`class pkgutil.ModuleInfo(module_finder, name, ispkg)`**

> A namedtuple that holds a brief summary of a module’s info.
>
> Added in version 3.6.

**`pkgutil.extend_path(path, name)`**

> Extend the search path for the modules which comprise a package. Intended use is to place the following code in a package’s `__init__.py`:
>
> ``` python
> from pkgutil import extend_path
> __path__ = extend_path(__path__, __name__)
> ```
>
> For each directory on [`sys.path`](sys.md#sys.path "sys.path") that has a subdirectory that matches the package name, add the subdirectory to the package’s [`__path__`](../reference/datamodel.md#module.__path__ "module.__path__"). This is useful if one wants to distribute different parts of a single logical package as multiple directories.
>
> It also looks for `*.pkg` files beginning where `*` matches the *name* argument. This feature is similar to `*.pth` files (see the [`site`](site.md#module-site "site: Module responsible for site-specific configuration.") module for more information), except that it doesn’t special-case lines starting with `import`. A `*.pkg` file is trusted at face value: apart from skipping blank lines and ignoring comments, all entries found in a `*.pkg` file are added to the path, regardless of whether they exist on the filesystem (this is a feature).
>
> If the input path is not a list (as is the case for frozen packages) it is returned unchanged. The input path is not modified; an extended copy is returned. Items are only appended to the copy at the end.
>
> It is assumed that [`sys.path`](sys.md#sys.path "sys.path") is a sequence. Items of `sys.path` that are not strings referring to existing directories are ignored. Unicode items on `sys.path` that cause errors when used as filenames may cause this function to raise an exception (in line with [`os.path.isdir()`](os.path.md#os.path.isdir "os.path.isdir") behavior).

**`pkgutil.get_importer(path_item)`**

> Retrieve a [finder](https://docs.python.org/3.14/glossary.html#term-finder) for the given *path_item*.
>
> The returned finder is cached in [`sys.path_importer_cache`](sys.md#sys.path_importer_cache "sys.path_importer_cache") if it was newly created by a path hook.
>
> The cache (or part of it) can be cleared manually if a rescan of [`sys.path_hooks`](sys.md#sys.path_hooks "sys.path_hooks") is necessary.
>
> Changed in version 3.3: Updated to be based directly on [`importlib`](importlib.md#module-importlib "importlib: The implementation of the import machinery.") rather than relying on the package internal [**PEP 302**](https://peps.python.org/pep-0302/) import emulation.

**`pkgutil.iter_importers(fullname='')`**

> Yield [finder](https://docs.python.org/3.14/glossary.html#term-finder) objects for the given module name.
>
> If *fullname* contains a `'.'`, the finders will be for the package containing *fullname*, otherwise they will be all registered top level finders (i.e. those on both [`sys.meta_path`](sys.md#sys.meta_path "sys.meta_path") and [`sys.path_hooks`](sys.md#sys.path_hooks "sys.path_hooks")).
>
> If the named module is in a package, that package is imported as a side effect of invoking this function.
>
> If no module name is specified, all top level finders are produced.
>
> Changed in version 3.3: Updated to be based directly on [`importlib`](importlib.md#module-importlib "importlib: The implementation of the import machinery.") rather than relying on the package internal [**PEP 302**](https://peps.python.org/pep-0302/) import emulation.

**`pkgutil.iter_modules(path=None, prefix='')`**

> Yields [`ModuleInfo`](#pkgutil.ModuleInfo "pkgutil.ModuleInfo") for all submodules on *path*, or, if *path* is `None`, all top-level modules on [`sys.path`](sys.md#sys.path "sys.path").
>
> *path* should be either `None` or a list of paths to look for modules in.
>
> *prefix* is a string to output on the front of every module name on output.
>
> > **Note:**
> >
> > Only works for a [finder](https://docs.python.org/3.14/glossary.html#term-finder) which defines an `iter_modules()` method. This interface is non-standard, so the module also provides implementations for [`importlib.machinery.FileFinder`](importlib.md#importlib.machinery.FileFinder "importlib.machinery.FileFinder") and [`zipimport.zipimporter`](zipimport.md#zipimport.zipimporter "zipimport.zipimporter").
>
> Changed in version 3.3: Updated to be based directly on [`importlib`](importlib.md#module-importlib "importlib: The implementation of the import machinery.") rather than relying on the package internal [**PEP 302**](https://peps.python.org/pep-0302/) import emulation.

**`pkgutil.walk_packages(path=None, prefix='', onerror=None)`**

> Yields [`ModuleInfo`](#pkgutil.ModuleInfo "pkgutil.ModuleInfo") for all modules recursively on *path*, or, if *path* is `None`, all accessible modules.
>
> *path* should be either `None` or a list of paths to look for modules in.
>
> *prefix* is a string to output on the front of every module name on output.
>
> Note that this function must import all *packages* (*not* all modules!) on the given *path*, in order to access the `__path__` attribute to find submodules.
>
> *onerror* is a function which gets called with one argument (the name of the package which was being imported) if any exception occurs while trying to import a package. If no *onerror* function is supplied, [`ImportError`](../builtins/exceptions.md#ImportError "ImportError")s are caught and ignored, while all other exceptions are propagated, terminating the search.
>
> Examples:
>
> ``` python
> # list all modules python can access
> walk_packages()
>
> # list all submodules of ctypes
> walk_packages(ctypes.__path__, ctypes.__name__ + '.')
> ```
>
> > **Note:**
> >
> > Only works for a [finder](https://docs.python.org/3.14/glossary.html#term-finder) which defines an `iter_modules()` method. This interface is non-standard, so the module also provides implementations for [`importlib.machinery.FileFinder`](importlib.md#importlib.machinery.FileFinder "importlib.machinery.FileFinder") and [`zipimport.zipimporter`](zipimport.md#zipimport.zipimporter "zipimport.zipimporter").
>
> Changed in version 3.3: Updated to be based directly on [`importlib`](importlib.md#module-importlib "importlib: The implementation of the import machinery.") rather than relying on the package internal [**PEP 302**](https://peps.python.org/pep-0302/) import emulation.

**`pkgutil.get_data(package, resource)`**

> Get a resource from a package.
>
> This is a wrapper for the [loader](https://docs.python.org/3.14/glossary.html#term-loader) [`get_data`](importlib.md#importlib.abc.ResourceLoader.get_data "importlib.abc.ResourceLoader.get_data") API. The *package* argument should be the name of a package, in standard module format (`foo.bar`). The *resource* argument should be in the form of a relative filename, using `/` as the path separator.
>
> The function returns a binary string that is the contents of the specified resource.
>
> This function uses the [loader](https://docs.python.org/3.14/glossary.html#term-loader) method [`get_data()`](importlib.md#importlib.abc.FileLoader.get_data "importlib.abc.FileLoader.get_data") to support modules installed in the filesystem, but also in zip files, databases, or elsewhere.
>
> For packages located in the filesystem, which have already been imported, this is the rough equivalent of:
>
> ``` python
> d = os.path.dirname(sys.modules[package].__file__)
> data = open(os.path.join(d, resource), 'rb').read()
> ```
>
> Like the [`open()`](../builtins/functions.md#open "open") function, `get_data()` can follow parent directories (`../`) and absolute paths (starting with `/` or `C:/`, for example). It can open compilation/installation artifacts like `.py` and `.pyc` files or files with [`reserved filenames`](os.path.md#os.path.isreserved "os.path.isreserved"). To be compatible with non-filesystem loaders, avoid using these features.
>
> > **Warning:**
> >
> > This function is intended for trusted input. It does not verify that *resource* “belongs” to *package*.
>
> If you use a user-provided *resource* path, consider verifying it. For example, require an alphanumeric filename with a known extension, or install and check a list of known resources.
>
> If the package cannot be located or loaded, or it uses a [loader](https://docs.python.org/3.14/glossary.html#term-loader) which does not support [`get_data`](importlib.md#importlib.abc.ResourceLoader.get_data "importlib.abc.ResourceLoader.get_data"), then `None` is returned. In particular, the loader for [namespace packages](https://docs.python.org/3.14/glossary.html#term-namespace-package) does not support `get_data`.
>
> > **See also:**
> >
> > The [`importlib.resources`](importlib.resources.md#module-importlib.resources "importlib.resources: Package resource reading, opening, and access") module provides structured access to module resources.

**`pkgutil.resolve_name(name)`**

> Resolve a name to an object.
>
> This functionality is used in numerous places in the standard library (see [bpo-12915](https://bugs.python.org/issue?@action=redirect&bpo=12915)) - and equivalent functionality is also in widely used third-party packages such as setuptools, Django and Pyramid.
>
> It is expected that *name* will be a string in one of the following formats, where W is shorthand for a valid Python identifier and dot stands for a literal period in these pseudo-regexes:
>
> - `W(.W)*`
>
> - `W(.W)*:(W(.W)*)?`
>
> The first form is intended for backward compatibility only. It assumes that some part of the dotted name is a package, and the rest is an object somewhere within that package, possibly nested inside other objects. Because the place where the package stops and the object hierarchy starts can’t be inferred by inspection, repeated attempts to import must be done with this form.
>
> In the second form, the caller makes the division point clear through the provision of a single colon: the dotted name to the left of the colon is a package to be imported, and the dotted name to the right is the object hierarchy within that package. Only one import is needed in this form. If it ends with the colon, then a module object is returned.
>
> The function will return an object (which might be a module), or raise one of the following exceptions:
>
> [`ValueError`](../builtins/exceptions.md#ValueError "ValueError") – if *name* isn’t in a recognised format.
>
> [`ImportError`](../builtins/exceptions.md#ImportError "ImportError") – if an import failed when it shouldn’t have.
>
> [`AttributeError`](../builtins/exceptions.md#AttributeError "AttributeError") – If a failure occurred when traversing the object hierarchy within the imported package to get to the desired object.
>
> Added in version 3.9.
