---
title: "ctypes — A foreign function library for Python"
source: https://docs.python.org/3.14/library/ctypes.html
---

# `ctypes` — A foreign function library for Python

**Source code:** [Lib/ctypes](https://github.com/python/cpython/tree/3.14/Lib/ctypes)

------------------------------------------------------------------------

`ctypes` is a foreign function library for Python. It provides C compatible data types, and allows calling functions in DLLs or shared libraries. It can be used to wrap these libraries in pure Python.

This is an [optional module](https://docs.python.org/3.14/glossary.html#term-optional-module). If it is missing from your copy of CPython, look for documentation from your distributor (that is, whoever provided Python to you). If you are the distributor, see [Requirements for optional modules](https://docs.python.org/3.14/using/configure.html#optional-module-requirements).

> **Warning:**
>
> `ctypes` provides low-level access to native libraries and the process’s memory, bypassing Python’s safety mechanisms and allowing execution of arbitrary native code. Incorrect use can corrupt data and objects, reveal sensitive information, cause crashes, or otherwise compromise the running process.

## ctypes tutorial

Note: Some code samples reference the ctypes [`c_int`](#ctypes.c_int "ctypes.c_int") type. On platforms where `sizeof(long) == sizeof(int)` it is an alias to [`c_long`](#ctypes.c_long "ctypes.c_long"). So, you should not be confused if `c_long` is printed if you would expect `c_int` — they are actually the same type.

### Loading dynamic link libraries

`ctypes` exports the [`cdll`](#ctypes.cdll "ctypes.cdll"), and on Windows [`windll`](#ctypes.windll "ctypes.windll") and [`oledll`](#ctypes.oledll "ctypes.oledll") objects, for loading dynamic link libraries.

You load libraries by accessing them as attributes of these objects. `cdll` loads libraries which export functions using the standard `cdecl` calling convention, while `windll` libraries call functions using the `stdcall` calling convention. [`oledll`](#ctypes.oledll "ctypes.oledll") also uses the `stdcall` calling convention, and assumes the functions return a Windows `HRESULT` error code. The error code is used to automatically raise an [`OSError`](../builtins/exceptions.md#OSError "OSError") exception when the function call fails.

Changed in version 3.3: Windows errors used to raise [`WindowsError`](../builtins/exceptions.md#WindowsError "WindowsError"), which is now an alias of [`OSError`](../builtins/exceptions.md#OSError "OSError").

Here are some examples for Windows. Note that `msvcrt` is the MS standard C library containing most standard C functions, and uses the `cdecl` calling convention:

``` pycon
>>> from ctypes import *
>>> print(windll.kernel32)
<WinDLL 'kernel32', handle ... at ...>
>>> print(cdll.msvcrt)
<CDLL 'msvcrt', handle ... at ...>
>>> libc = cdll.msvcrt
>>>
```

Windows appends the usual `.dll` file suffix automatically.

> **Note:**
>
> Accessing the standard C library through `cdll.msvcrt` will use an outdated version of the library that may be incompatible with the one being used by Python. Where possible, use native Python functionality, or else import and use the `msvcrt` module.

Other systems require the filename *including* the extension to load a library, so attribute access can not be used to load libraries. Either the [`LoadLibrary()`](#ctypes.LibraryLoader.LoadLibrary "ctypes.LibraryLoader.LoadLibrary") method of the dll loaders should be used, or you should load the library by creating an instance of [`CDLL`](#ctypes.CDLL "ctypes.CDLL") by calling the constructor.

For example, on Linux:

``` pycon
>>> cdll.LoadLibrary("libc.so.6")
<CDLL 'libc.so.6', handle ... at ...>
>>> libc = CDLL("libc.so.6")
>>> libc
<CDLL 'libc.so.6', handle ... at ...>
>>>
```

On macOS:

``` pycon
>>> cdll.LoadLibrary("libc.dylib")
<CDLL 'libc.dylib', handle ... at ...>
>>> libc = CDLL("libc.dylib")
>>> libc
<CDLL 'libc.dylib', handle ... at ...>
```

### Accessing functions from loaded dlls

Functions are accessed as attributes of dll objects:

``` pycon
>>> libc.printf
<_FuncPtr object at 0x...>
>>> print(windll.kernel32.GetModuleHandleA)
<_FuncPtr object at 0x...>
>>> print(windll.kernel32.MyOwnFunction)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
  File "ctypes.py", line 239, in __getattr__
    func = _StdcallFuncPtr(name, self)
AttributeError: function 'MyOwnFunction' not found
>>>
```

Note that win32 system dlls like `kernel32` and `user32` often export ANSI as well as UNICODE versions of a function. The UNICODE version is exported with a `W` appended to the name, while the ANSI version is exported with an `A` appended to the name. The win32 `GetModuleHandle` function, which returns a *module handle* for a given module name, has the following C prototype, and a macro is used to expose one of them as `GetModuleHandle` depending on whether UNICODE is defined or not:

``` python
/* ANSI version */
HMODULE GetModuleHandleA(LPCSTR lpModuleName);
/* UNICODE version */
HMODULE GetModuleHandleW(LPCWSTR lpModuleName);
```

*windll* does not try to select one of them by magic, you must access the version you need by specifying `GetModuleHandleA` or `GetModuleHandleW` explicitly, and then call it with bytes or string objects respectively.

Sometimes, dlls export functions with names which aren’t valid Python identifiers, like `"??2@YAPAXI@Z"`. In this case you have to use [`getattr()`](../builtins/functions.md#getattr "getattr") to retrieve the function:

``` pycon
>>> getattr(cdll.msvcrt, "??2@YAPAXI@Z")
<_FuncPtr object at 0x...>
>>>
```

On Windows, some dlls export functions not by name but by ordinal. These functions can be accessed by indexing the dll object with the ordinal number:

``` pycon
>>> cdll.kernel32[1]
<_FuncPtr object at 0x...>
>>> cdll.kernel32[0]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
  File "ctypes.py", line 310, in __getitem__
    func = _StdcallFuncPtr(name, self)
AttributeError: function ordinal 0 not found
>>>
```

### Calling functions

You can call these functions like any other Python callable. This example uses the `rand()` function, which takes no arguments and returns a pseudo-random integer:

``` pycon
>>> print(libc.rand())
1804289383
```

On Windows, you can call the `GetModuleHandleA()` function, which returns a win32 module handle (passing `None` as single argument to call it with a `NULL` pointer):

``` pycon
>>> print(hex(windll.kernel32.GetModuleHandleA(None)))
0x1d000000
>>>
```

`ctypes` cannot determine a function’s calling convention or signature. Consult the function’s C header file or documentation to choose the correct calling convention and set the [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes") attribute, as described in [Specifying the required argument types (function prototypes)](#ctypes-specifying-required-argument-types). Without `argtypes`, the number of arguments is not checked. Calling a function with an incorrect calling convention or with incorrect arguments can corrupt memory or crash Python.

On Windows, `ctypes` uses win32 structured exception handling to prevent crashes from general protection faults when functions are called with invalid argument values:

``` pycon
>>> windll.kernel32.GetModuleHandleA(32)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
OSError: exception: access violation reading 0x00000020
>>>
```

The [`faulthandler`](faulthandler.md#module-faulthandler "faulthandler: Dump the Python traceback.") module can help debug crashes, such as segmentation faults produced by erroneous C library calls.

`None`, integers, bytes objects and (unicode) strings are the only native Python objects that can directly be used as parameters in these function calls. `None` is passed as a C `NULL` pointer, bytes objects and strings are passed as pointer to the memory block that contains their data (char* or wchar_t*). Python integers are passed as the platform’s default C int type, their value is masked to fit into the C type.

Before we move on calling functions with other parameter types, we have to learn more about `ctypes` data types.

### Fundamental data types

`ctypes` defines a number of primitive C compatible data types:

| ctypes type | C type | Python type | [`_type_`](#ctypes._SimpleCData._type_ "ctypes._SimpleCData._type_") |
|---|---|---|---|
| [`c_bool`](#ctypes.c_bool "ctypes.c_bool") | \_Bool | [`bool`](../builtins/functions.html#bool "bool") | `'?'` |
| [`c_char`](#ctypes.c_char "ctypes.c_char") | char | 1-character [`bytes`](../builtins/stdtypes.html#bytes "bytes") | `'c'` |
| [`c_wchar`](#ctypes.c_wchar "ctypes.c_wchar") | `wchar_t` | 1-character [`str`](../builtins/stdtypes.html#str "str") | `'u'` |
| [`c_byte`](#ctypes.c_byte "ctypes.c_byte") | char | [`int`](../builtins/functions.html#int "int") | `'b'` |
| [`c_ubyte`](#ctypes.c_ubyte "ctypes.c_ubyte") | unsigned char | [`int`](../builtins/functions.html#int "int") | `'B'` |
| [`c_short`](#ctypes.c_short "ctypes.c_short") | short | [`int`](../builtins/functions.html#int "int") | `'h'` |
| [`c_ushort`](#ctypes.c_ushort "ctypes.c_ushort") | unsigned short | [`int`](../builtins/functions.html#int "int") | `'H'` |
| [`c_int`](#ctypes.c_int "ctypes.c_int") | int | [`int`](../builtins/functions.html#int "int") | `'i'` \* |
| [`c_int8`](#ctypes.c_int8 "ctypes.c_int8") | `int8_t` | [`int`](../builtins/functions.html#int "int") | \* |
| [`c_int16`](#ctypes.c_int16 "ctypes.c_int16") | `int16_t` | [`int`](../builtins/functions.html#int "int") | \* |
| [`c_int32`](#ctypes.c_int32 "ctypes.c_int32") | `int32_t` | [`int`](../builtins/functions.html#int "int") | \* |
| [`c_int64`](#ctypes.c_int64 "ctypes.c_int64") | `int64_t` | [`int`](../builtins/functions.html#int "int") | \* |
| [`c_uint`](#ctypes.c_uint "ctypes.c_uint") | unsigned int | [`int`](../builtins/functions.html#int "int") | `'I'` \* |
| [`c_uint8`](#ctypes.c_uint8 "ctypes.c_uint8") | `uint8_t` | [`int`](../builtins/functions.html#int "int") | \* |
| [`c_uint16`](#ctypes.c_uint16 "ctypes.c_uint16") | `uint16_t` | [`int`](../builtins/functions.html#int "int") | \* |
| [`c_uint32`](#ctypes.c_uint32 "ctypes.c_uint32") | `uint32_t` | [`int`](../builtins/functions.html#int "int") | \* |
| [`c_uint64`](#ctypes.c_uint64 "ctypes.c_uint64") | `uint64_t` | [`int`](../builtins/functions.html#int "int") | \* |
| [`c_long`](#ctypes.c_long "ctypes.c_long") | long | [`int`](../builtins/functions.html#int "int") | `'l'` |
| [`c_ulong`](#ctypes.c_ulong "ctypes.c_ulong") | unsigned long | [`int`](../builtins/functions.html#int "int") | `'L'` |
| [`c_longlong`](#ctypes.c_longlong "ctypes.c_longlong") | long long | [`int`](../builtins/functions.html#int "int") | `'q'` \* |
| [`c_ulonglong`](#ctypes.c_ulonglong "ctypes.c_ulonglong") | unsigned long long | [`int`](../builtins/functions.html#int "int") | `'Q'` \* |
| [`c_size_t`](#ctypes.c_size_t "ctypes.c_size_t") | `size_t` | [`int`](../builtins/functions.html#int "int") | \* |
| [`c_ssize_t`](#ctypes.c_ssize_t "ctypes.c_ssize_t") | [`Py_ssize_t`](../c-api/intro.html#c.Py_ssize_t "Py_ssize_t") | [`int`](../builtins/functions.html#int "int") | \* |
| [`c_time_t`](#ctypes.c_time_t "ctypes.c_time_t") | `time_t` | [`int`](../builtins/functions.html#int "int") | \* |
| [`c_float`](#ctypes.c_float "ctypes.c_float") | float | [`float`](../builtins/functions.html#float "float") | `'f'` |
| [`c_double`](#ctypes.c_double "ctypes.c_double") | double | [`float`](../builtins/functions.html#float "float") | `'d'` |
| [`c_longdouble`](#ctypes.c_longdouble "ctypes.c_longdouble") | long double | [`float`](../builtins/functions.html#float "float") | `'g'` \* |
| [`c_char_p`](#ctypes.c_char_p "ctypes.c_char_p") | char\* (NUL terminated) | [`bytes`](../builtins/stdtypes.html#bytes "bytes") or `None` | `'z'` |
| [`c_wchar_p`](#ctypes.c_wchar_p "ctypes.c_wchar_p") | wchar_t\* (NUL terminated) | [`str`](../builtins/stdtypes.html#str "str") or `None` | `'Z'` |
| [`c_void_p`](#ctypes.c_void_p "ctypes.c_void_p") | void\* | [`int`](../builtins/functions.html#int "int") or `None` | `'P'` |
| [`py_object`](#ctypes.py_object "ctypes.py_object") | [PyObject](../c-api/structures.html#c.PyObject "PyObject")\* | [`object`](../builtins/functions.html#object "object") | `'O'` |
| [VARIANT_BOOL](#ctypes-wintypes) | short int | [`bool`](../builtins/functions.html#bool "bool") | `'v'` |

Additionally, if IEC 60559 compatible complex arithmetic (Annex G) is supported in both C and `libffi`, the following complex types are available:

| ctypes type | C type | Python type | [`_type_`](#ctypes._SimpleCData._type_ "ctypes._SimpleCData._type_") |
|---|---|---|---|
| [`c_float_complex`](#ctypes.c_float_complex "ctypes.c_float_complex") | float complex | [`complex`](../builtins/functions.html#complex "complex") | `'F'` |
| [`c_double_complex`](#ctypes.c_double_complex "ctypes.c_double_complex") | double complex | [`complex`](../builtins/functions.html#complex "complex") | `'D'` |
| [`c_longdouble_complex`](#ctypes.c_longdouble_complex "ctypes.c_longdouble_complex") | long double complex | [`complex`](../builtins/functions.html#complex "complex") | `'G'` |

All these types can be created by calling them with an optional initializer of the correct type and value:

``` pycon
>>> c_int()
c_long(0)
>>> c_wchar_p("Hello, World")
c_wchar_p(140018365411392)
>>> c_ushort(-3)
c_ushort(65533)
>>>
```

The constructors for numeric types will convert input using [`__bool__()`](../reference/datamodel.md#object.__bool__ "object.__bool__"), [`__index__()`](../reference/datamodel.md#object.__index__ "object.__index__") (for `int`), [`__float__()`](../reference/datamodel.md#object.__float__ "object.__float__") or [`__complex__()`](../reference/datamodel.md#object.__complex__ "object.__complex__"). This means [`c_bool`](#ctypes.c_bool "ctypes.c_bool") accepts any object with a truth value:

``` pycon
>>> empty_list = []
>>> c_bool(empty_list)
c_bool(False)
```

Since these types are mutable, their value can also be changed afterwards:

``` pycon
>>> i = c_int(42)
>>> print(i)
c_long(42)
>>> print(i.value)
42
>>> i.value = -99
>>> print(i.value)
-99
>>>
```

Assigning a new value to instances of the pointer types [`c_char_p`](#ctypes.c_char_p "ctypes.c_char_p"), [`c_wchar_p`](#ctypes.c_wchar_p "ctypes.c_wchar_p"), and [`c_void_p`](#ctypes.c_void_p "ctypes.c_void_p") changes the *memory location* they point to, *not the contents* of the memory block (of course not, because Python string objects are immutable):

``` pycon
>>> s = "Hello, World"
>>> c_s = c_wchar_p(s)
>>> print(c_s)
c_wchar_p(139966785747344)
>>> print(c_s.value)
Hello World
>>> c_s.value = "Hi, there"
>>> print(c_s)              # the memory location has changed
c_wchar_p(139966783348904)
>>> print(c_s.value)
Hi, there
>>> print(s)                # first object is unchanged
Hello, World
>>>
```

You should be careful, however, not to pass them to functions expecting pointers to mutable memory. If you need mutable memory blocks, ctypes has a [`create_string_buffer()`](#ctypes.create_string_buffer "ctypes.create_string_buffer") function which creates these in various ways. The current memory block contents can be accessed (or changed) with the `raw` property; if you want to access it as NUL terminated string, use the `value` property:

``` pycon
>>> from ctypes import *
>>> p = create_string_buffer(3)            # create a 3 byte buffer, initialized to NUL bytes
>>> print(sizeof(p), repr(p.raw))
3 b'\x00\x00\x00'
>>> p = create_string_buffer(b"Hello")     # create a buffer containing a NUL terminated string
>>> print(sizeof(p), repr(p.raw))
6 b'Hello\x00'
>>> print(repr(p.value))
b'Hello'
>>> p = create_string_buffer(b"Hello", 10) # create a 10 byte buffer
>>> print(sizeof(p), repr(p.raw))
10 b'Hello\x00\x00\x00\x00\x00'
>>> p.value = b"Hi"
>>> print(sizeof(p), repr(p.raw))
10 b'Hi\x00lo\x00\x00\x00\x00\x00'
>>>
```

The [`create_string_buffer()`](#ctypes.create_string_buffer "ctypes.create_string_buffer") function replaces the old `c_buffer()` function (which is still available as an alias). To create a mutable memory block containing unicode characters of the C type `wchar_t`, use the [`create_unicode_buffer()`](#ctypes.create_unicode_buffer "ctypes.create_unicode_buffer") function.

### Calling functions, continued

Note that printf prints to the real standard output channel, *not* to [`sys.stdout`](sys.md#sys.stdout "sys.stdout"), so these examples will only work at the console prompt, not from within *IDLE* or *PythonWin*:

``` pycon
>>> printf = libc.printf
>>> printf(b"Hello, %s\n", b"World!")
Hello, World!
14
>>> printf(b"Hello, %S\n", "World!")
Hello, World!
14
>>> printf(b"%d bottles of beer\n", 42)
42 bottles of beer
19
>>> printf(b"%f bottles of beer\n", 42.5)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ctypes.ArgumentError: argument 2: TypeError: Don't know how to convert parameter 2
>>>
```

As has been mentioned before, all Python types except integers, strings, and bytes objects have to be wrapped in their corresponding `ctypes` type, so that they can be converted to the required C data type:

``` pycon
>>> printf(b"An int %d, a double %f\n", 1234, c_double(3.14))
An int 1234, a double 3.140000
31
>>>
```

### Calling variadic functions

On a lot of platforms calling variadic functions through ctypes is exactly the same as calling functions with a fixed number of parameters. On some platforms, and in particular ARM64 for Apple Platforms, the calling convention for variadic functions is different than that for regular functions.

On those platforms it is required to specify the [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes") attribute for the regular, non-variadic, function arguments:

``` python
libc.printf.argtypes = [ctypes.c_char_p]
```

Because specifying the attribute does not inhibit portability it is advised to always specify [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes") for all variadic functions.

### Calling functions with your own custom data types

You can also customize `ctypes` argument conversion to allow instances of your own classes be used as function arguments. `ctypes` looks for an `_as_parameter_` attribute and uses this as the function argument. The attribute must be an integer, string, bytes, a `ctypes` instance, or an object with an `_as_parameter_` attribute:

``` pycon
>>> class Bottles:
...     def __init__(self, number):
...         self._as_parameter_ = number
...
>>> bottles = Bottles(42)
>>> printf(b"%d bottles of beer\n", bottles)
42 bottles of beer
19
>>>
```

If you don’t want to store the instance’s data in the `_as_parameter_` instance variable, you could define a [`@property`](../builtins/functions.md#property "property") which makes the attribute available on request.

### Specifying the required argument types (function prototypes)

It is possible to specify the required argument types of functions exported from DLLs by setting the [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes") attribute.

[`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes") must be a sequence of C data types (the `printf()` function is probably not a good example here, because it takes a variable number and different types of parameters depending on the format string, on the other hand this is quite handy to experiment with this feature):

``` pycon
>>> printf.argtypes = [c_char_p, c_char_p, c_int, c_double]
>>> printf(b"String '%s', Int %d, Double %f\n", b"Hi", 10, 2.2)
String 'Hi', Int 10, Double 2.200000
37
>>>
```

Specifying a format protects against incompatible argument types (just as a prototype for a C function), and tries to convert the arguments to valid types:

``` pycon
>>> printf(b"%d %d %d", 1, 2, 3)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ctypes.ArgumentError: argument 2: TypeError: 'int' object cannot be interpreted as ctypes.c_char_p
>>> printf(b"%s %d %f\n", b"X", 2, 3)
X 2 3.000000
13
>>>
```

Setting [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes") also causes `ctypes` to raise [`TypeError`](../builtins/exceptions.md#TypeError "TypeError") if too few arguments are passed:

``` pycon
>>> printf(b"%s %d %f\n", b"X", 2)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: this function takes at least 4 arguments (3 given)
```

Functions using the `stdcall` calling convention require exactly as many arguments as there are items in [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes"). Functions using the `cdecl` calling convention accept additional arguments, to support variadic functions. The declaration must match the function’s actual signature; ctypes cannot verify this.

If you have defined your own classes which you pass to function calls, you have to implement a [`from_param()`](#ctypes._CData.from_param "ctypes._CData.from_param") class method for them to be able to use them in the [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes") sequence. The `from_param()` class method receives the Python object passed to the function call, it should do a typecheck or whatever is needed to make sure this object is acceptable, and then return the object itself, its `_as_parameter_` attribute, or whatever you want to pass as the C function argument in this case. Again, the result should be an integer, string, bytes, a `ctypes` instance, or an object with an `_as_parameter_` attribute.

### Return types

By default functions are assumed to return the C int type. Other return types can be specified by setting the [`restype`](#ctypes._CFuncPtr.restype "ctypes._CFuncPtr.restype") attribute of the function object.

The C prototype of `time()` is `time_t time(time_t *)`. Because `time_t` might be of a different type than the default return type int, you should specify the `restype` attribute:

``` pycon
>>> libc.time.restype = c_time_t
```

The argument types can be specified using [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes"):

``` pycon
>>> libc.time.argtypes = (POINTER(c_time_t),)
```

To call the function with a `NULL` pointer as first argument, use `None`:

``` pycon
>>> print(libc.time(None))
1150640792
```

Here is a more advanced example, it uses the `strchr()` function, which expects a string pointer and a char, and returns a pointer to a string:

``` pycon
>>> strchr = libc.strchr
>>> strchr(b"abcdef", ord("d"))
8059983
>>> strchr.restype = c_char_p    # c_char_p is a pointer to a string
>>> strchr(b"abcdef", ord("d"))
b'def'
>>> print(strchr(b"abcdef", ord("x")))
None
>>>
```

If you want to avoid the [`ord("x")`](../builtins/functions.md#ord "ord") calls above, you can set the [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes") attribute, and the second argument will be converted from a single character Python bytes object into a C char:

``` pycon
>>> strchr.restype = c_char_p
>>> strchr.argtypes = [c_char_p, c_char]
>>> strchr(b"abcdef", b"d")
b'def'
>>> strchr(b"abcdef", b"def")
Traceback (most recent call last):
ctypes.ArgumentError: argument 2: TypeError: one character bytes, bytearray or integer expected
>>> print(strchr(b"abcdef", b"x"))
None
>>> strchr(b"abcdef", b"d")
b'def'
>>>
```

You can also use a callable Python object (a function or a class for example) as the [`restype`](#ctypes._CFuncPtr.restype "ctypes._CFuncPtr.restype") attribute, if the foreign function returns an integer. The callable will be called with the *integer* the C function returns, and the result of this call will be used as the result of your function call. This is useful to check for error return values and automatically raise an exception:

``` pycon
>>> GetModuleHandle = windll.kernel32.GetModuleHandleA
>>> def ValidHandle(value):
...     if value == 0:
...         raise WinError()
...     return value
...
>>>
>>> GetModuleHandle.restype = ValidHandle
>>> GetModuleHandle(None)
486539264
>>> GetModuleHandle("something silly")
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
  File "<stdin>", line 3, in ValidHandle
OSError: [Errno 126] The specified module could not be found.
>>>
```

`WinError` is a function which will call Windows `FormatMessage()` api to get the string representation of an error code, and *returns* an exception. `WinError` takes an optional error code parameter, if no one is used, it calls [`GetLastError()`](#ctypes.GetLastError "ctypes.GetLastError") to retrieve it.

Please note that a much more powerful error checking mechanism is available through the [`errcheck`](#ctypes._CFuncPtr.errcheck "ctypes._CFuncPtr.errcheck") attribute; see the reference manual for details.

### Passing pointers (or: passing parameters by reference)

Sometimes a C api function expects a *pointer* to a data type as parameter, probably to write into the corresponding location, or if the data is too large to be passed by value. This is also known as *passing parameters by reference*.

`ctypes` exports the [`byref()`](#ctypes.byref "ctypes.byref") function which is used to pass parameters by reference. The same effect can be achieved with the [`pointer()`](#ctypes.pointer "ctypes.pointer") function, although `pointer()` does a lot more work since it constructs a real pointer object, so it is faster to use `byref()` if you don’t need the pointer object in Python itself:

``` pycon
>>> i = c_int()
>>> f = c_float()
>>> s = create_string_buffer(b'\000' * 32)
>>> print(i.value, f.value, repr(s.value))
0 0.0 b''
>>> libc.sscanf(b"1 3.14 Hello", b"%d %f %s",
...             byref(i), byref(f), s)
3
>>> print(i.value, f.value, repr(s.value))
1 3.1400001049 b'Hello'
>>>
```

### Structures and unions

Structures and unions must derive from the [`Structure`](#ctypes.Structure "ctypes.Structure") and [`Union`](#ctypes.Union "ctypes.Union") base classes which are defined in the `ctypes` module. Each subclass must define a [`_fields_`](#ctypes.Structure._fields_ "ctypes.Structure._fields_") attribute. `_fields_` must be a list of *2-tuples*, containing a *field name* and a *field type*.

The field type must be a `ctypes` type like [`c_int`](#ctypes.c_int "ctypes.c_int"), or any other derived `ctypes` type: structure, union, array, pointer.

Here is a simple example of a POINT structure, which contains two integers named *x* and *y*, and also shows how to initialize a structure in the constructor:

``` pycon
>>> from ctypes import *
>>> class POINT(Structure):
...     _fields_ = [("x", c_int),
...                 ("y", c_int)]
...
>>> point = POINT(10, 20)
>>> print(point.x, point.y)
10 20
>>> point = POINT(y=5)
>>> print(point.x, point.y)
0 5
>>> POINT(1, 2, 3)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: too many initializers
>>>
```

You can, however, build much more complicated structures. A structure can itself contain other structures by using a structure as a field type.

Here is a RECT structure which contains two POINTs named *upperleft* and *lowerright*:

``` pycon
>>> class RECT(Structure):
...     _fields_ = [("upperleft", POINT),
...                 ("lowerright", POINT)]
...
>>> rc = RECT(point)
>>> print(rc.upperleft.x, rc.upperleft.y)
0 5
>>> print(rc.lowerright.x, rc.lowerright.y)
0 0
>>>
```

Nested structures can also be initialized in the constructor in several ways:

``` pycon
>>> r = RECT(POINT(1, 2), POINT(3, 4))
>>> r = RECT((1, 2), (3, 4))
```

Field [descriptor](https://docs.python.org/3.14/glossary.html#term-descriptor)s can be retrieved from the *class*, they are useful for debugging because they can provide useful information. See [`CField`](#ctypes.CField "ctypes.CField"):

``` pycon
>>> POINT.x
<ctypes.CField 'x' type=c_int, ofs=0, size=4>
>>> POINT.y
<ctypes.CField 'y' type=c_int, ofs=4, size=4>
>>>
```

> **Warning:**
>
> `ctypes` does not support passing unions or structures with bit-fields to functions by value. While this may work on 32-bit x86, it’s not guaranteed by the library to work in the general case. Unions and structures with bit-fields should always be passed to functions by pointer.

### Structure/union layout, alignment and byte order

By default, Structure and Union fields are laid out in the same way the C compiler does it. It is possible to override this behavior entirely by specifying a [`_layout_`](#ctypes.Structure._layout_ "ctypes.Structure._layout_") class attribute in the subclass definition; see the attribute documentation for details.

It is possible to specify the maximum alignment for the fields and/or for the structure itself by setting the class attributes [`_pack_`](#ctypes.Structure._pack_ "ctypes.Structure._pack_") and/or [`_align_`](#ctypes.Structure._align_ "ctypes.Structure._align_"), respectively. See the attribute documentation for details.

`ctypes` uses the native byte order for Structures and Unions. To build structures with non-native byte order, you can use one of the [`BigEndianStructure`](#ctypes.BigEndianStructure "ctypes.BigEndianStructure"), [`LittleEndianStructure`](#ctypes.LittleEndianStructure "ctypes.LittleEndianStructure"), [`BigEndianUnion`](#ctypes.BigEndianUnion "ctypes.BigEndianUnion"), and [`LittleEndianUnion`](#ctypes.LittleEndianUnion "ctypes.LittleEndianUnion") base classes. These classes cannot contain pointer fields.

### Bit fields in structures and unions

It is possible to create structures and unions containing bit fields. Bit fields are only possible for integer fields, the bit width is specified as the third item in the [`_fields_`](#ctypes.Structure._fields_ "ctypes.Structure._fields_") tuples:

``` pycon
>>> class Int(Structure):
...     _fields_ = [("first_16", c_int, 16),
...                 ("second_16", c_int, 16)]
...
>>> print(Int.first_16)
<ctypes.CField 'first_16' type=c_int, ofs=0, bit_size=16, bit_offset=0>
>>> print(Int.second_16)
<ctypes.CField 'second_16' type=c_int, ofs=0, bit_size=16, bit_offset=16>
```

It is important to note that bit field allocation and layout in memory are not defined as a C standard; their implementation is compiler-specific. By default, Python will attempt to match the behavior of a “native” compiler for the current platform. See the [`_layout_`](#ctypes.Structure._layout_ "ctypes.Structure._layout_") attribute for details on the default behavior and how to change it.

### Arrays

Arrays are sequences, containing a fixed number of instances of the same type.

The recommended way to create array types is by multiplying a data type with a positive integer:

``` python
TenPointsArrayType = POINT * 10
```

Here is an example of a somewhat artificial data type, a structure containing 4 POINTs among other stuff:

``` pycon
>>> from ctypes import *
>>> class POINT(Structure):
...     _fields_ = ("x", c_int), ("y", c_int)
...
>>> class MyStruct(Structure):
...     _fields_ = [("a", c_int),
...                 ("b", c_float),
...                 ("point_array", POINT * 4)]
>>>
>>> print(len(MyStruct().point_array))
4
>>>
```

Instances are created in the usual way, by calling the class:

``` python
arr = TenPointsArrayType()
for pt in arr:
    print(pt.x, pt.y)
```

The above code print a series of `0 0` lines, because the array contents is initialized to zeros.

Initializers of the correct type can also be specified:

``` pycon
>>> from ctypes import *
>>> TenIntegers = c_int * 10
>>> ii = TenIntegers(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
>>> print(ii)
<c_long_Array_10 object at 0x...>
>>> for i in ii: print(i, end=" ")
...
1 2 3 4 5 6 7 8 9 10
>>>
```

### Pointers

Pointer instances are created by calling the [`pointer()`](#ctypes.pointer "ctypes.pointer") function on a `ctypes` type:

``` pycon
>>> from ctypes import *
>>> i = c_int(42)
>>> pi = pointer(i)
>>>
```

Pointer instances have a [`contents`](#ctypes._Pointer.contents "ctypes._Pointer.contents") attribute which returns the object to which the pointer points, the `i` object above:

``` pycon
>>> pi.contents
c_long(42)
>>>
```

Note that `ctypes` does not have OOR (original object return), it constructs a new, equivalent object each time you retrieve an attribute:

``` pycon
>>> pi.contents is i
False
>>> pi.contents is pi.contents
False
>>>
```

Assigning another [`c_int`](#ctypes.c_int "ctypes.c_int") instance to the pointer’s contents attribute would cause the pointer to point to the memory location where this is stored:

``` pycon
>>> i = c_int(99)
>>> pi.contents = i
>>> pi.contents
c_long(99)
>>>
```

Pointer instances can also be indexed with integers:

``` pycon
>>> pi[0]
99
>>>
```

Assigning to an integer index changes the pointed to value:

``` pycon
>>> print(i)
c_long(99)
>>> pi[0] = 22
>>> print(i)
c_long(22)
>>>
```

It is also possible to use indexes different from 0, but you must know what you’re doing, just as in C: You can access or change arbitrary memory locations. Generally you only use this feature if you receive a pointer from a C function, and you *know* that the pointer actually points to an array instead of a single item.

> **Warning:**
>
> Because pointer objects support subscription, they implicitly support [iteration](https://docs.python.org/3.14/glossary.html#term-iterator). Unless doing this in a controlled manner, such as by manually calling [`next()`](../builtins/functions.md#next "next") on a [`pointer()`](#ctypes.pointer "ctypes.pointer") iterator, this will typically lead to infinite loops or crashes, because ctypes has no way of knowing when to stop iteration. In other words, a `pointer` iterator will infinitely yield arbitrary memory.

Behind the scenes, the [`pointer()`](#ctypes.pointer "ctypes.pointer") function does more than simply create pointer instances, it has to create pointer *types* first. This is done with the [`POINTER()`](#ctypes.POINTER "ctypes.POINTER") function, which accepts any `ctypes` type, and returns a new type:

``` pycon
>>> PI = POINTER(c_int)
>>> PI
<class 'ctypes.LP_c_long'>
>>> PI(42)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: expected c_long instead of int
>>> PI(c_int(42))
<ctypes.LP_c_long object at 0x...>
>>>
```

Calling the pointer type without an argument creates a `NULL` pointer. `NULL` pointers have a `False` boolean value:

``` pycon
>>> null_ptr = POINTER(c_int)()
>>> print(bool(null_ptr))
False
>>>
```

`ctypes` checks for `NULL` when dereferencing pointers (but dereferencing invalid non-`NULL` pointers would crash Python):

``` pycon
>>> null_ptr[0]
Traceback (most recent call last):
    ....
ValueError: NULL pointer access
>>>

>>> null_ptr[0] = 1234
Traceback (most recent call last):
    ....
ValueError: NULL pointer access
>>>
```

### Thread safety without the GIL

From Python 3.13 onward, the [GIL](https://docs.python.org/3.14/glossary.html#term-GIL) can be disabled on the [free-threaded build](https://docs.python.org/3.14/glossary.html#term-free-threaded-build). In ctypes, reads and writes to a single object concurrently is safe, but not across multiple objects:

> ``` pycon
> >>> number = c_int(42)
> >>> pointer_a = pointer(number)
> >>> pointer_b = pointer(number)
> ```

In the above, it’s only safe for one object to read and write to the address at once if the GIL is disabled. So, `pointer_a` can be shared and written to across multiple threads, but only if `pointer_b` is not also attempting to do the same. If this is an issue, consider using a [`threading.Lock`](threading.md#threading.Lock "threading.Lock") to synchronize access to memory:

> ``` pycon
> >>> import threading
> >>> lock = threading.Lock()
> >>> # Thread 1
> >>> with lock:
> ...    pointer_a.contents = 24
> >>> # Thread 2
> >>> with lock:
> ...    pointer_b.contents = 42
> ```

### Type conversions

Usually, ctypes does strict type checking. This means, if you have `POINTER(c_int)` in the [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes") list of a function or as the type of a member field in a structure definition, only instances of exactly the same type are accepted. There are some exceptions to this rule, where ctypes accepts other objects. For example, you can pass compatible array instances instead of pointer types. So, for `POINTER(c_int)`, ctypes accepts an array of c_int:

``` pycon
>>> class Bar(Structure):
...     _fields_ = [("count", c_int), ("values", POINTER(c_int))]
...
>>> bar = Bar()
>>> bar.values = (c_int * 3)(1, 2, 3)
>>> bar.count = 3
>>> for i in range(bar.count):
...     print(bar.values[i])
...
1
2
3
>>>
```

In addition, if a function argument is explicitly declared to be a pointer type (such as `POINTER(c_int)`) in [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes"), an object of the pointed type (`c_int` in this case) can be passed to the function. ctypes will apply the required [`byref()`](#ctypes.byref "ctypes.byref") conversion in this case automatically.

To set a POINTER type field to `NULL`, you can assign `None`:

``` pycon
>>> bar.values = None
>>>
```

Sometimes you have instances of incompatible types. In C, you can cast one type into another type. `ctypes` provides a [`cast()`](#ctypes.cast "ctypes.cast") function which can be used in the same way. The `Bar` structure defined above accepts `POINTER(c_int)` pointers or [`c_int`](#ctypes.c_int "ctypes.c_int") arrays for its `values` field, but not instances of other types:

``` pycon
>>> bar.values = (c_byte * 4)()
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: incompatible types, c_byte_Array_4 instance instead of LP_c_long instance
>>>
```

For these cases, the [`cast()`](#ctypes.cast "ctypes.cast") function is handy.

The [`cast()`](#ctypes.cast "ctypes.cast") function can be used to cast a ctypes instance into a pointer to a different ctypes data type. `cast()` takes two parameters, a ctypes object that is or can be converted to a pointer of some kind, and a ctypes pointer type. It returns an instance of the second argument, which references the same memory block as the first argument:

``` pycon
>>> a = (c_byte * 4)()
>>> cast(a, POINTER(c_int))
<ctypes.LP_c_long object at ...>
>>>
```

So, [`cast()`](#ctypes.cast "ctypes.cast") can be used to assign to the `values` field of `Bar` the structure:

``` pycon
>>> bar = Bar()
>>> bar.values = cast((c_byte * 4)(), POINTER(c_int))
>>> print(bar.values[0])
0
>>>
```

### Incomplete Types

*Incomplete Types* are structures, unions or arrays whose members are not yet specified. In C, they are specified by forward declarations, which are defined later:

``` python
struct cell; /* forward declaration */

struct cell {
    char *name;
    struct cell *next;
};
```

The straightforward translation into ctypes code would be this, but it does not work:

``` pycon
>>> class cell(Structure):
...     _fields_ = [("name", c_char_p),
...                 ("next", POINTER(cell))]
...
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
  File "<stdin>", line 2, in cell
NameError: name 'cell' is not defined
>>>
```

because the new `class cell` is not available in the class statement itself. In `ctypes`, we can define the `cell` class and set the [`_fields_`](#ctypes.Structure._fields_ "ctypes.Structure._fields_") attribute later, after the class statement:

``` pycon
>>> from ctypes import *
>>> class cell(Structure):
...     pass
...
>>> cell._fields_ = [("name", c_char_p),
...                  ("next", POINTER(cell))]
>>>
```

Let’s try it. We create two instances of `cell`, and let them point to each other, and finally follow the pointer chain a few times:

``` pycon
>>> c1 = cell()
>>> c1.name = b"foo"
>>> c2 = cell()
>>> c2.name = b"bar"
>>> c1.next = pointer(c2)
>>> c2.next = pointer(c1)
>>> p = c1
>>> for i in range(8):
...     print(p.name, end=" ")
...     p = p.next[0]
...
foo bar foo bar foo bar foo bar
>>>
```

### Callback functions

`ctypes` allows creating C callable function pointers from Python callables. These are sometimes called *callback functions*.

First, you must create a class for the callback function. The class knows the calling convention, the return type, and the number and types of arguments this function will receive.

The [`CFUNCTYPE()`](#ctypes.CFUNCTYPE "ctypes.CFUNCTYPE") factory function creates types for callback functions using the `cdecl` calling convention. On Windows, the [`WINFUNCTYPE()`](#ctypes.WINFUNCTYPE "ctypes.WINFUNCTYPE") factory function creates types for callback functions using the `stdcall` calling convention.

Both of these factory functions are called with the result type as first argument, and the callback functions expected argument types as the remaining arguments.

I will present an example here which uses the standard C library’s `qsort()` function, that is used to sort items with the help of a callback function. `qsort()` will be used to sort an array of integers:

``` pycon
>>> IntArray5 = c_int * 5
>>> ia = IntArray5(5, 1, 7, 33, 99)
>>> qsort = libc.qsort
>>> qsort.restype = None
>>>
```

`qsort()` must be called with a pointer to the data to sort, the number of items in the data array, the size of one item, and a pointer to the comparison function, the callback. The callback will then be called with two pointers to items, and it must return a negative integer if the first item is smaller than the second, a zero if they are equal, and a positive integer otherwise.

So our callback function receives pointers to integers, and must return an integer. First we create the `type` for the callback function:

``` pycon
>>> CMPFUNC = CFUNCTYPE(c_int, POINTER(c_int), POINTER(c_int))
>>>
```

To get started, here is a simple callback that shows the values it gets passed:

``` pycon
>>> def py_cmp_func(a, b):
...     print("py_cmp_func", a[0], b[0])
...     return 0
...
>>> cmp_func = CMPFUNC(py_cmp_func)
>>>
```

The result:

``` pycon
>>> qsort(ia, len(ia), sizeof(c_int), cmp_func)
py_cmp_func 5 1
py_cmp_func 33 99
py_cmp_func 7 33
py_cmp_func 5 7
py_cmp_func 1 7
>>>
```

Now we can actually compare the two items and return a useful result:

``` pycon
>>> def py_cmp_func(a, b):
...     print("py_cmp_func", a[0], b[0])
...     return a[0] - b[0]
...
>>>
>>> qsort(ia, len(ia), sizeof(c_int), CMPFUNC(py_cmp_func))
py_cmp_func 5 1
py_cmp_func 33 99
py_cmp_func 7 33
py_cmp_func 1 7
py_cmp_func 5 7
>>>
```

As we can easily check, our array is sorted now:

``` pycon
>>> for i in ia: print(i, end=" ")
...
1 5 7 33 99
>>>
```

The function factories can be used as decorator factories, so we may as well write:

``` pycon
>>> @CFUNCTYPE(c_int, POINTER(c_int), POINTER(c_int))
... def py_cmp_func(a, b):
...     print("py_cmp_func", a[0], b[0])
...     return a[0] - b[0]
...
>>> qsort(ia, len(ia), sizeof(c_int), py_cmp_func)
py_cmp_func 5 1
py_cmp_func 33 99
py_cmp_func 7 33
py_cmp_func 1 7
py_cmp_func 5 7
>>>
```

> **Note:**
>
> Make sure you keep references to [`CFUNCTYPE()`](#ctypes.CFUNCTYPE "ctypes.CFUNCTYPE") objects as long as they are used from C code. `ctypes` doesn’t, and if you don’t, they may be garbage collected, crashing your program when a callback is made.
>
> Also, note that if the callback function is called in a thread created outside of Python’s control (e.g. by the foreign code that calls the callback), ctypes creates a new dummy Python thread on every invocation. This behavior is correct for most purposes, but it means that values stored with [`threading.local`](threading.md#threading.local "threading.local") will *not* survive across different callbacks, even when those calls are made from the same C thread.

### Accessing values exported from dlls

Some shared libraries not only export functions, they also export variables. An example in the Python library itself is the [`Py_Version`](https://docs.python.org/3.14/c-api/apiabiversion.html#c.Py_Version "Py_Version"), Python runtime version number encoded in a single constant integer.

`ctypes` can access values like this with the [`in_dll()`](#ctypes._CData.in_dll "ctypes._CData.in_dll") class methods of the type. *pythonapi* is a predefined symbol giving access to the Python C api:

``` pycon
>>> version = ctypes.c_int.in_dll(ctypes.pythonapi, "Py_Version")
>>> print(hex(version.value))
0x30c00a0
```

An extended example which also demonstrates the use of pointers accesses the [`PyImport_FrozenModules`](https://docs.python.org/3.14/c-api/import.html#c.PyImport_FrozenModules "PyImport_FrozenModules") pointer exported by Python.

Quoting the docs for that value:

> This pointer is initialized to point to an array of [`_frozen`](https://docs.python.org/3.14/c-api/import.html#c._frozen "_frozen") records, terminated by one whose members are all `NULL` or zero. When a frozen module is imported, it is searched in this table. Third-party code could play tricks with this to provide a dynamically created collection of frozen modules.

So manipulating this pointer could even prove useful. To restrict the example size, we show only how this table can be read with `ctypes`:

``` pycon
>>> from ctypes import *
>>>
>>> class struct_frozen(Structure):
...     _fields_ = [("name", c_char_p),
...                 ("code", POINTER(c_ubyte)),
...                 ("size", c_int),
...                 ("get_code", POINTER(c_ubyte)),  # Function pointer
...                ]
...
>>>
```

We have defined the [`_frozen`](https://docs.python.org/3.14/c-api/import.html#c._frozen "_frozen") data type, so we can get the pointer to the table:

``` pycon
>>> FrozenTable = POINTER(struct_frozen)
>>> table = FrozenTable.in_dll(pythonapi, "_PyImport_FrozenBootstrap")
>>>
```

Since `table` is a `pointer` to the array of `struct_frozen` records, we can iterate over it, but we just have to make sure that our loop terminates, because pointers have no size. Sooner or later it would probably crash with an access violation or whatever, so it’s better to break out of the loop when we hit the `NULL` entry:

``` pycon
>>> for item in table:
...     if item.name is None:
...         break
...     print(item.name.decode("ascii"), item.size)
...
_frozen_importlib 31764
_frozen_importlib_external 41499
zipimport 12345
>>>
```

The fact that standard Python has a frozen module and a frozen package (indicated by the negative `size` member) is not well known, it is only used for testing. Try it out with `import __hello__` for example.

### Surprises

There are some edges in `ctypes` where you might expect something other than what actually happens.

Consider the following example:

``` pycon
>>> from ctypes import *
>>> class POINT(Structure):
...     _fields_ = ("x", c_int), ("y", c_int)
...
>>> class RECT(Structure):
...     _fields_ = ("a", POINT), ("b", POINT)
...
>>> p1 = POINT(1, 2)
>>> p2 = POINT(3, 4)
>>> rc = RECT(p1, p2)
>>> print(rc.a.x, rc.a.y, rc.b.x, rc.b.y)
1 2 3 4
>>> # now swap the two points
>>> rc.a, rc.b = rc.b, rc.a
>>> print(rc.a.x, rc.a.y, rc.b.x, rc.b.y)
3 4 3 4
>>>
```

Hm. We certainly expected the last statement to print `3 4 1 2`. What happened? Here are the steps of the `rc.a, rc.b = rc.b, rc.a` line above:

``` pycon
>>> temp0, temp1 = rc.b, rc.a
>>> rc.a = temp0
>>> rc.b = temp1
>>>
```

Note that `temp0` and `temp1` are objects still using the internal buffer of the `rc` object above. So executing `rc.a = temp0` copies the buffer contents of `temp0` into `rc` ‘s buffer. This, in turn, changes the contents of `temp1`. So, the last assignment `rc.b = temp1`, doesn’t have the expected effect.

Keep in mind that retrieving sub-objects from Structure, Unions, and Arrays doesn’t *copy* the sub-object, instead it retrieves a wrapper object accessing the root-object’s underlying buffer.

Another example that may behave differently from what one would expect is this:

``` pycon
>>> s = c_char_p()
>>> s.value = b"abc def ghi"
>>> s.value
b'abc def ghi'
>>> s.value is s.value
False
>>>
```

> **Note:**
>
> Objects instantiated from [`c_char_p`](#ctypes.c_char_p "ctypes.c_char_p") can only have their value set to bytes or integers.

Why is it printing `False`? ctypes instances are objects containing a memory block plus some [descriptor](https://docs.python.org/3.14/glossary.html#term-descriptor)s accessing the contents of the memory. Storing a Python object in the memory block does not store the object itself, instead the `contents` of the object is stored. Accessing the contents again constructs a new Python object each time!

### Variable-sized data types

`ctypes` provides some support for variable-sized arrays and structures.

The [`resize()`](#ctypes.resize "ctypes.resize") function can be used to resize the memory buffer of an existing ctypes object. The function takes the object as first argument, and the requested size in bytes as the second argument. The memory block cannot be made smaller than the natural memory block specified by the objects type, a [`ValueError`](../builtins/exceptions.md#ValueError "ValueError") is raised if this is tried:

``` pycon
>>> short_array = (c_short * 4)()
>>> print(sizeof(short_array))
8
>>> resize(short_array, 4)
Traceback (most recent call last):
    ...
ValueError: minimum size is 8
>>> resize(short_array, 32)
>>> sizeof(short_array)
32
>>> sizeof(type(short_array))
8
>>>
```

This is nice and fine, but how would one access the additional elements contained in this array? Since the type still only knows about 4 elements, we get errors accessing other elements:

``` pycon
>>> short_array[:]
[0, 0, 0, 0]
>>> short_array[7]
Traceback (most recent call last):
    ...
IndexError: invalid index
>>>
```

Another way to use variable-sized data types with `ctypes` is to use the dynamic nature of Python, and (re-)define the data type after the required size is already known, on a case by case basis.

## ctypes reference

### Finding shared libraries

When programming in a compiled language, shared libraries are accessed when compiling/linking a program, and when the program is run.

The purpose of the [`find_library()`](#ctypes.util.find_library "ctypes.util.find_library") function is to locate a library in a way similar to what the compiler or runtime loader does (on platforms with several versions of a shared library the most recent should be loaded), while the ctypes library loaders act like when a program is run, and call the runtime loader directly.

The `ctypes.util` module provides a function which can help to determine the library to load.

**`ctypes.util.find_library(name)`**

> Try to find a library and return a pathname. *name* is the library name without any prefix like *lib*, suffix like `.so`, `.dylib` or version number (this is the form used for the posix linker option `-l`). If no library can be found, returns `None`.

The exact functionality is system dependent.

On Linux, [`find_library()`](#ctypes.util.find_library "ctypes.util.find_library") tries to run external programs (`/sbin/ldconfig`, `gcc`, `objdump` and `ld`) to find the library file. It returns the filename of the library file.

Note that if the output of these programs does not correspond to the dynamic linker used by Python, the result of this function may be misleading.

Changed in version 3.6: On Linux, the value of the environment variable `LD_LIBRARY_PATH` is used when searching for libraries, if a library cannot be found by any other means.

Here are some examples:

``` pycon
>>> from ctypes.util import find_library
>>> find_library("m")
'libm.so.6'
>>> find_library("c")
'libc.so.6'
>>> find_library("bz2")
'libbz2.so.1.0'
>>>
```

On macOS and Android, [`find_library()`](#ctypes.util.find_library "ctypes.util.find_library") uses the system’s standard naming schemes and paths to locate the library, and returns a full pathname if successful:

``` pycon
>>> from ctypes.util import find_library
>>> find_library("c")
'/usr/lib/libc.dylib'
>>> find_library("m")
'/usr/lib/libm.dylib'
>>> find_library("bz2")
'/usr/lib/libbz2.dylib'
>>> find_library("AGL")
'/System/Library/Frameworks/AGL.framework/AGL'
>>>
```

On Windows, [`find_library()`](#ctypes.util.find_library "ctypes.util.find_library") searches along the system search path, and returns the full pathname, but since there is no predefined naming scheme a call like `find_library("c")` will fail and return `None`.

If wrapping a shared library with `ctypes`, it *may* be better to determine the shared library name at development time, and hardcode that into the wrapper module instead of using [`find_library()`](#ctypes.util.find_library "ctypes.util.find_library") to locate the library at runtime.

### Listing loaded shared libraries

When writing code that relies on code loaded from shared libraries, it can be useful to know which shared libraries have already been loaded into the current process.

The `ctypes.util` module provides the [`dllist()`](#ctypes.util.dllist "ctypes.util.dllist") function, which calls the different APIs provided by the various platforms to help determine which shared libraries have already been loaded into the current process.

The exact output of this function will be system dependent. On most platforms, the first entry of this list represents the current process itself, which may be an empty string. For example, on glibc-based Linux, the return may look like:

``` pycon
>>> from ctypes.util import dllist
>>> dllist()
['', 'linux-vdso.so.1', '/lib/x86_64-linux-gnu/libm.so.6', '/lib/x86_64-linux-gnu/libc.so.6', ... ]
```

### Loading shared libraries

There are several ways to load shared libraries into the Python process. One way is to instantiate [`CDLL`](#ctypes.CDLL "ctypes.CDLL") or one of its subclasses:

**`class ctypes.CDLL(name, mode=DEFAULT_MODE, handle=None, use_errno=False, use_last_error=False, winmode=None)`**

> Represents a loaded shared library.
>
> Functions in this library use the standard C calling convention, and are assumed to return int. The Python [global interpreter lock](https://docs.python.org/3.14/glossary.html#term-global-interpreter-lock) is released before calling any function exported by these libraries, and reacquired afterwards. For different function behavior, use a subclass: [`OleDLL`](#ctypes.OleDLL "ctypes.OleDLL"), [`WinDLL`](#ctypes.WinDLL "ctypes.WinDLL"), or [`PyDLL`](#ctypes.PyDLL "ctypes.PyDLL").
>
> If you have an existing [`handle`](#ctypes.CDLL._handle "ctypes.CDLL._handle") to an already loaded shared library, it can be passed as the *handle* argument to wrap the opened library in a new `CDLL` object. In this case, *name* is only used to set the [`_name`](#ctypes.CDLL._name "ctypes.CDLL._name") attribute, but it may be adjusted and/or validated.
>
> If *handle* is `None`, the underlying platform’s *[dlopen(3)](https://manpages.debian.org/dlopen(3))* or `LoadLibrary()` function is used to load the library into the process, and to get a handle to it.
>
> *name* is the pathname of the shared library to open. If *name* does not contain a path separator, the library is found in a platform-specific way.
>
> On non-Windows systems, *name* can be `None`. In this case, `dlopen()` is called with `NULL`, which opens the main program as a “library”. (Some systems do the same if *name* is empty; `None`/`NULL` is more portable.)
>
> > **CPython implementation detail:**
> >
> > Since CPython is linked to `libc`, a `None` *name* is often used to access the C standard library:
> >
> > ``` pycon
> > >>> printf = ctypes.CDLL(None).printf
> > >>> printf.argtypes = [ctypes.c_char_p]
> > >>> printf(b"hello\n")
> > hello
> > 6
> > ```
> >
> > To access the Python C API, prefer [`ctypes.pythonapi`](#ctypes.pythonapi "ctypes.pythonapi") which works across platforms.
>
> The *mode* parameter can be used to specify how the library is loaded. For details, consult the *[dlopen(3)](https://manpages.debian.org/dlopen(3))* manpage. On Windows, *mode* is ignored. On posix systems, RTLD_NOW is always added, and is not configurable.
>
> The *use_errno* parameter, when set to true, enables a ctypes mechanism that allows accessing the system [`errno`](errno.md#module-errno "errno: Standard errno system symbols.") error number in a safe way. `ctypes` maintains a thread-local copy of the system’s `errno` variable; if you call foreign functions created with `use_errno=True` then the `errno` value before the function call is swapped with the ctypes private copy, the same happens immediately after the function call. This mechanism only works for libraries that use the same C runtime library as the interpreter itself. A library linked against a different C runtime (for example, a different CRT on Windows) has its own `errno`, which `ctypes` cannot observe.
>
> The function [`ctypes.get_errno()`](#ctypes.get_errno "ctypes.get_errno") returns the value of the ctypes private copy, and the function [`ctypes.set_errno()`](#ctypes.set_errno "ctypes.set_errno") changes the ctypes private copy to a new value and returns the former value.
>
> The *use_last_error* parameter, when set to true, enables the same mechanism for the Windows error code which is managed by the [`GetLastError()`](#ctypes.GetLastError "ctypes.GetLastError") and `SetLastError()` Windows API functions; [`ctypes.get_last_error()`](#ctypes.get_last_error "ctypes.get_last_error") and [`ctypes.set_last_error()`](#ctypes.set_last_error "ctypes.set_last_error") are used to request and change the ctypes private copy of the windows error code.
>
> The *winmode* parameter is used on Windows to specify how the library is loaded (since *mode* is ignored). It takes any value that is valid for the Win32 API `LoadLibraryEx` flags parameter. When omitted, the default is to use the flags that result in the most secure DLL load, which avoids issues such as DLL hijacking. Passing the full path to the DLL is the safest way to ensure the correct library and dependencies are loaded.
>
> On Windows creating a `CDLL` instance may fail even if the DLL name exists. When a dependent DLL of the loaded DLL is not found, a [`OSError`](../builtins/exceptions.md#OSError "OSError") error is raised with the message *“[WinError 126] The specified module could not be found”.* This error message does not contain the name of the missing DLL because the Windows API does not return this information making this error hard to diagnose. To resolve this error and determine which DLL is not found, you need to find the list of dependent DLLs and determine which one is not found using Windows debugging and tracing tools.
>
> > **See also:**
> >
> > [Microsoft DUMPBIN tool](https://learn.microsoft.com/en-us/cpp/build/reference/dumpbin-reference?view=msvc-170) – A tool to find DLL dependents.
>
> Changed in version 3.8: Added *winmode* parameter.
>
> Changed in version 3.12: The *name* parameter can now be a [path-like object](https://docs.python.org/3.14/glossary.html#term-path-like-object).
>
> Instances of this class have no public methods. Functions exported by the shared library can be accessed as attributes or by index. Please note that accessing the function through an attribute caches the result and therefore accessing it repeatedly returns the same object each time. On the other hand, accessing it through an index returns a new object each time:
>
> ``` pycon
> >>> from ctypes import CDLL
> >>> libc = CDLL("libc.so.6")  # On Linux
> >>> libc.time == libc.time
> True
> >>> libc['time'] == libc['time']
> False
> ```
>
> The following public attributes are available. Their name starts with an underscore to not clash with exported function names:
>
> **`_handle`**
>
> > The system handle used to access the library.
>
> **`_name`**
>
> > The name of the library passed in the constructor.

**`class ctypes.OleDLL`**

> See [`CDLL`](#ctypes.CDLL "ctypes.CDLL"), the superclass, for common information.
>
> Functions in this library use the `stdcall` calling convention, and are assumed to return the windows specific [`HRESULT`](#ctypes.HRESULT "ctypes.HRESULT") code. `HRESULT` values contain information specifying whether the function call failed or succeeded, together with additional error code. If the return value signals a failure, an [`OSError`](../builtins/exceptions.md#OSError "OSError") is automatically raised.
>
> [Availability](intro.md#availability): Windows
>
> Changed in version 3.3: [`WindowsError`](../builtins/exceptions.md#WindowsError "WindowsError") used to be raised, which is now an alias of [`OSError`](../builtins/exceptions.md#OSError "OSError").

**`class ctypes.WinDLL`**

> See [`CDLL`](#ctypes.CDLL "ctypes.CDLL"), the superclass, for common information.
>
> Functions in these libraries use the `stdcall` calling convention, and are assumed to return int by default.
>
> [Availability](intro.md#availability): Windows

**`class ctypes.PyDLL`**

> See [`CDLL`](#ctypes.CDLL "ctypes.CDLL"), the superclass, for common information.
>
> When functions in this library are called, the Python GIL is *not* released during the function call, and after the function execution the Python error flag is checked. If the error flag is set, a Python exception is raised.
>
> Thus, this is only useful to call Python C API functions directly.

**`ctypes.RTLD_GLOBAL`**

> Flag to use as *mode* parameter. On platforms where this flag is not available, it is defined as the integer zero.

**`ctypes.RTLD_LOCAL`**

> Flag to use as *mode* parameter. On platforms where this is not available, it is the same as *RTLD_GLOBAL*.

**`ctypes.DEFAULT_MODE`**

> The default mode which is used to load shared libraries. On OSX 10.3, this is *RTLD_GLOBAL*, otherwise it is the same as *RTLD_LOCAL*.

Shared libraries can also be loaded by using one of the prefabricated objects, which are instances of the [`LibraryLoader`](#ctypes.LibraryLoader "ctypes.LibraryLoader") class, either by calling the [`LoadLibrary()`](#ctypes.LibraryLoader.LoadLibrary "ctypes.LibraryLoader.LoadLibrary") method, or by retrieving the library as attribute of the loader instance.

**`class ctypes.LibraryLoader(dlltype)`**

> Class which loads shared libraries. *dlltype* should be one of the [`CDLL`](#ctypes.CDLL "ctypes.CDLL"), [`PyDLL`](#ctypes.PyDLL "ctypes.PyDLL"), [`WinDLL`](#ctypes.WinDLL "ctypes.WinDLL"), or [`OleDLL`](#ctypes.OleDLL "ctypes.OleDLL") types.
>
> `__getattr__()` has special behavior: It allows loading a shared library by accessing it as attribute of a library loader instance. The result is cached, so repeated attribute accesses return the same library each time.
>
> **`LoadLibrary(name)`**
>
> > Load a shared library into the process and return it. This method always returns a new instance of the library.

These prefabricated library loaders are available:

**`ctypes.cdll`**

> Creates [`CDLL`](#ctypes.CDLL "ctypes.CDLL") instances.

**`ctypes.windll`**

> Creates [`WinDLL`](#ctypes.WinDLL "ctypes.WinDLL") instances.
>
> [Availability](intro.md#availability): Windows

**`ctypes.oledll`**

> Creates [`OleDLL`](#ctypes.OleDLL "ctypes.OleDLL") instances.
>
> [Availability](intro.md#availability): Windows

**`ctypes.pydll`**

> Creates [`PyDLL`](#ctypes.PyDLL "ctypes.PyDLL") instances.

For accessing the C Python api directly, a ready-to-use Python shared library object is available:

**`ctypes.pythonapi`**

> An instance of [`PyDLL`](#ctypes.PyDLL "ctypes.PyDLL") that exposes Python C API functions as attributes. Note that all these functions are assumed to return C int, which is of course not always the truth, so you have to assign the correct `restype` attribute to use these functions.
>
> > > **Note:**
> > >
> > > If the Python interpreter is statically linked, this may be `None`.

Loading a library through any of these objects raises an [auditing event](sys.md#auditing) `ctypes.dlopen` with string argument `name`, the name used to load the library.

Accessing a function on a loaded library raises an auditing event `ctypes.dlsym` with arguments `library` (the library object) and `name` (the symbol’s name as a string or integer).

In cases when only the library handle is available rather than the object, accessing a function raises an auditing event `ctypes.dlsym/handle` with arguments `handle` (the raw library handle) and `name`.

### Foreign functions

As explained in the previous section, foreign functions can be accessed as attributes of loaded shared libraries. The function objects created in this way by default accept any number of arguments, accept any ctypes data instances as arguments, and return the default result type specified by the library loader.

They are instances of a private local class `_FuncPtr` (not exposed in `ctypes`) which inherits from the private [`_CFuncPtr`](#ctypes._CFuncPtr "ctypes._CFuncPtr") class:

``` pycon
>>> import ctypes
>>> lib = ctypes.CDLL(None)
>>> issubclass(lib._FuncPtr, ctypes._CFuncPtr)
True
>>> lib._FuncPtr is ctypes._CFuncPtr
False
```

**`class ctypes._CFuncPtr`**

> Base class for C callable foreign functions.
>
> Instances of foreign functions are also C compatible data types; they represent C function pointers.
>
> This behavior can be customized by assigning to special attributes of the foreign function object.
>
> **`restype`**
>
> > Assign a ctypes type to specify the result type of the foreign function. Use `None` for void, a function not returning anything.
> >
> > It is possible to assign a callable Python object that is not a ctypes type, in this case the function is assumed to return a C int, and the callable will be called with this integer, allowing further processing or error checking. Using this is deprecated, for more flexible post processing or error checking use a ctypes data type as `restype` and assign a callable to the [`errcheck`](#ctypes._CFuncPtr.errcheck "ctypes._CFuncPtr.errcheck") attribute.
>
> **`argtypes`**
>
> > Assign a tuple of ctypes types to specify the argument types that the function accepts. [`TypeError`](../builtins/exceptions.md#TypeError "TypeError") is raised if the function is called with fewer arguments than the length of this tuple. Functions using the `stdcall` calling convention also raise `TypeError` if called with more arguments; functions using the `cdecl` calling convention accept additional, unspecified arguments as well.
> >
> > When a foreign function is called, each actual argument is passed to the [`from_param()`](#ctypes._CData.from_param "ctypes._CData.from_param") class method of the items in the [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes") tuple, this method allows adapting the actual argument to an object that the foreign function accepts. For example, a [`c_char_p`](#ctypes.c_char_p "ctypes.c_char_p") item in the `argtypes` tuple will convert a string passed as argument into a bytes object using ctypes conversion rules.
> >
> > New: It is now possible to put items in argtypes which are not ctypes types, but each item must have a [`from_param()`](#ctypes._CData.from_param "ctypes._CData.from_param") method which returns a value usable as argument (integer, string, ctypes instance). This allows defining adapters that can adapt custom objects as function parameters.
>
> **`errcheck`**
>
> > Assign a Python function or another callable to this attribute. The callable will be called with three or more arguments:
> >
> > **`callable(result, func, arguments)`**
> >
> > > *result* is what the foreign function returns, as specified by the `restype` attribute.
> > >
> > > *func* is the foreign function object itself, this allows reusing the same callable object to check or post process the results of several functions.
> > >
> > > *arguments* is a tuple containing the parameters passed to the function call, including any output parameters that `ctypes` created for the call; this allows specializing the behavior on the arguments used.
> >
> > If the callable returns the *arguments* tuple it received, unchanged, `ctypes` continues its normal processing of the result, which includes returning output parameters (see [Function prototypes](#ctypes-function-prototypes)). Any other object returned by the callable is returned from the foreign function call instead. The callable can also check the result value and raise an exception if the foreign function call failed.
> >
> > For example, this callable raises an exception when the foreign function signals failure with a negative return value, and otherwise leaves the result to `ctypes`:
> >
> > ``` python
> > def errcheck(result, func, arguments):
> >     if result < 0:
> >         raise RuntimeError(f"call failed with error {result}")
> >     return arguments
> > ```
> >
> > This one instead replaces the result, converting a C `int` used as a boolean into a [`bool`](../builtins/functions.md#bool "bool"):
> >
> > ``` python
> > def errcheck(result, func, arguments):
> >     return result != 0
> > ```

On Windows, when a foreign function call raises a system exception (for example, due to an access violation), it will be captured and replaced with a suitable Python exception. Further, an auditing event `ctypes.set_exception` with argument `code` will be raised, allowing an audit hook to replace the exception with its own.

Some ways to invoke foreign function calls as well as some of the functions in this module may raise an auditing event `ctypes.call_function` with arguments `function pointer` and `arguments`.

### Function prototypes

Foreign functions can also be created by instantiating function prototypes. Function prototypes are similar to function prototypes in C; they describe a function (return type, argument types, calling convention) without defining an implementation. The factory functions must be called with the desired result type and the argument types of the function, and can be used as decorator factories, and as such, be applied to functions through the `@wrapper` syntax. See [Callback functions](#ctypes-callback-functions) for examples.

**`ctypes.CFUNCTYPE(restype, *argtypes, use_errno=False, use_last_error=False)`**

> The returned function prototype creates functions that use the standard C calling convention. The function will release the GIL during the call. If *use_errno* is set to true, the ctypes private copy of the system [`errno`](errno.md#module-errno "errno: Standard errno system symbols.") variable is exchanged with the real `errno` value before and after the call; *use_last_error* does the same for the Windows error code.

**`ctypes.WINFUNCTYPE(restype, *argtypes, use_errno=False, use_last_error=False)`**

> The returned function prototype creates functions that use the `stdcall` calling convention. The function will release the GIL during the call. *use_errno* and *use_last_error* have the same meaning as above.
>
> [Availability](intro.md#availability): Windows

**`ctypes.PYFUNCTYPE(restype, *argtypes)`**

> The returned function prototype creates functions that use the Python calling convention. Unlike [`CFUNCTYPE()`](#ctypes.CFUNCTYPE "ctypes.CFUNCTYPE") and [`WINFUNCTYPE()`](#ctypes.WINFUNCTYPE "ctypes.WINFUNCTYPE"), ctypes does *not* release the GIL before calling the foreign function, so the function may safely use the Python C API. Note that this does not prevent the GIL from being released *during* the call.

Function prototypes created by these factory functions can be instantiated in different ways, depending on the type and number of the parameters in the call:

**`prototype(address)`**

> Returns a foreign function at the specified address which must be an integer.

**`prototype(callable)`**

> Create a C callable function (a callback function) from a Python *callable*.

**`prototype(func_spec[, paramflags])`**

> Returns a foreign function exported by a shared library. *func_spec* must be a 2-tuple `(name_or_ordinal, library)`. The first item is the name of the exported function as string, or the ordinal of the exported function as small integer. The second item is the shared library instance.

**`prototype(vtbl_index, name[, paramflags[, iid]])`**

> Returns a foreign function that will call a COM method. *vtbl_index* is the index into the virtual function table, a small non-negative integer. *name* is name of the COM method. *iid* is an optional pointer to the interface identifier which is used in extended error reporting.
>
> If *iid* is not specified, an [`OSError`](../builtins/exceptions.md#OSError "OSError") is raised if the COM method call fails. If *iid* is specified, a [`COMError`](#ctypes.COMError "ctypes.COMError") is raised instead.
>
> COM methods use a special calling convention: They require a pointer to the COM interface as first argument, in addition to those parameters that are specified in the `argtypes` tuple.
>
> [Availability](intro.md#availability): Windows

The optional *paramflags* parameter creates foreign function wrappers with much more functionality than the features described above.

*paramflags* must be a tuple of the same length as [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes").

Each item in this tuple contains further information about a parameter, it must be a tuple containing one, two, or three items.

The first item is an integer containing a combination of direction flags for the parameter:

> 1  
> Specifies an input parameter to the function.
>
> 2  
> Output parameter. The foreign function fills in a value.
>
> 4  
> Input parameter which defaults to the integer zero.

The optional second item is the parameter name as string. If this is specified, the foreign function can be called with named parameters.

The optional third item is the default value for this parameter.

The following example demonstrates how to wrap the Windows `MessageBoxW` function so that it supports default parameters and named arguments. The C declaration from the windows header file is this:

``` python
WINUSERAPI int WINAPI
MessageBoxW(
    HWND hWnd,
    LPCWSTR lpText,
    LPCWSTR lpCaption,
    UINT uType);
```

Here is the wrapping with `ctypes`:

``` pycon
>>> from ctypes import c_int, WINFUNCTYPE, windll
>>> from ctypes.wintypes import HWND, LPCWSTR, UINT
>>> prototype = WINFUNCTYPE(c_int, HWND, LPCWSTR, LPCWSTR, UINT)
>>> paramflags = (1, "hwnd", 0), (1, "text", "Hi"), (1, "caption", "Hello from ctypes"), (1, "flags", 0)
>>> MessageBox = prototype(("MessageBoxW", windll.user32), paramflags)
```

The `MessageBox` foreign function can now be called in these ways:

``` pycon
>>> MessageBox()
>>> MessageBox(text="Spam, spam, spam")
>>> MessageBox(flags=2, text="foo bar")
```

A second example demonstrates output parameters. The win32 `GetWindowRect` function retrieves the dimensions of a specified window by copying them into `RECT` structure that the caller has to supply. Here is the C declaration:

``` python
WINUSERAPI BOOL WINAPI
GetWindowRect(
     HWND hWnd,
     LPRECT lpRect);
```

Here is the wrapping with `ctypes`:

``` pycon
>>> from ctypes import POINTER, WINFUNCTYPE, windll, WinError
>>> from ctypes.wintypes import BOOL, HWND, RECT
>>> prototype = WINFUNCTYPE(BOOL, HWND, POINTER(RECT))
>>> paramflags = (1, "hwnd"), (2, "lprect")
>>> GetWindowRect = prototype(("GetWindowRect", windll.user32), paramflags)
>>>
```

Functions with output parameters will automatically return the output parameter value if there is a single one, or a tuple containing the output parameter values when there are more than one, so the GetWindowRect function now returns a RECT instance, when called.

Output parameters can be combined with the [`errcheck`](#ctypes._CFuncPtr.errcheck "ctypes._CFuncPtr.errcheck") protocol to do further output processing and error checking. The win32 `GetWindowRect` api function returns a `BOOL` to signal success or failure, so this function could do the error checking, and raises an exception when the api call failed:

``` pycon
>>> def errcheck(result, func, args):
...     if not result:
...         raise WinError()
...     return args
...
>>> GetWindowRect.errcheck = errcheck
>>>
```

If the [`errcheck`](#ctypes._CFuncPtr.errcheck "ctypes._CFuncPtr.errcheck") function returns the argument tuple it receives unchanged, `ctypes` continues the normal processing it does on the output parameters. If you want to return a tuple of window coordinates instead of a `RECT` instance, you can retrieve the fields in the function and return them instead, the normal processing will no longer take place:

``` pycon
>>> def errcheck(result, func, args):
...     if not result:
...         raise WinError()
...     rc = args[1]
...     return rc.left, rc.top, rc.bottom, rc.right
...
>>> GetWindowRect.errcheck = errcheck
>>>
```

### Utility functions

**`ctypes.addressof(obj)`**

> Returns the address of the memory buffer as integer. *obj* must be an instance of a ctypes type.
>
> Raises an [auditing event](sys.md#auditing) `ctypes.addressof` with argument `obj`.

**`ctypes.alignment(obj_or_type)`**

> Returns the alignment requirements of a ctypes type. *obj_or_type* must be a ctypes type or instance.

**`ctypes.byref(obj[, offset])`**

> Returns a light-weight pointer to *obj*, which must be an instance of a ctypes type. *offset* defaults to zero, and must be an integer that will be added to the internal pointer value.
>
> `byref(obj, offset)` corresponds to this C code:
>
> ``` python
> (((char *)&obj) + offset)
> ```
>
> The returned object can only be used as a foreign function call parameter. It behaves similar to `pointer(obj)`, but the construction is a lot faster.

**`ctypes.CopyComPointer(src, dst)`**

> Copies a COM pointer from *src* to *dst* and returns the Windows specific `HRESULT` value.
>
> If *src* is not `NULL`, its `AddRef` method is called, incrementing the reference count.
>
> In contrast, the reference count of *dst* will not be decremented before assigning the new value. Unless *dst* is `NULL`, the caller is responsible for decrementing the reference count by calling its `Release` method when necessary.
>
> [Availability](intro.md#availability): Windows
>
> Added in version 3.14.

**`ctypes.cast(obj, type)`**

> This function is similar to the cast operator in C. It returns a new instance of *type* which points to the same memory block as *obj*. *type* must be a pointer type, and *obj* must be an object that can be interpreted as a pointer.

**`ctypes.create_string_buffer(init, size=None)`**

**`ctypes.create_string_buffer(size)`**

> This function creates a mutable character buffer. The returned object is a ctypes array of [`c_char`](#ctypes.c_char "ctypes.c_char").
>
> If *size* is given (and not `None`), it must be an [`int`](../builtins/functions.md#int "int"). It specifies the size of the returned array.
>
> If the *init* argument is given, it must be [`bytes`](../builtins/stdtypes.md#bytes "bytes"). It is used to initialize the array items. Bytes not initialized this way are set to zero (NUL).
>
> If *size* is not given (or if it is `None`), the buffer is made one element larger than *init*, effectively adding a NUL terminator.
>
> If both arguments are given, *size* must not be less than `len(init)`.
>
> > **Warning:**
> >
> > If *size* is equal to `len(init)`, a NUL terminator is not added. Do not treat such a buffer as a C string.
>
> For example:
>
> ``` pycon
> >>> bytes(create_string_buffer(2))
> b'\x00\x00'
> >>> bytes(create_string_buffer(b'ab'))
> b'ab\x00'
> >>> bytes(create_string_buffer(b'ab', 2))
> b'ab'
> >>> bytes(create_string_buffer(b'ab', 4))
> b'ab\x00\x00'
> >>> bytes(create_string_buffer(b'abcdef', 2))
> Traceback (most recent call last):
>    ...
> ValueError: byte string too long
> ```
>
> Raises an [auditing event](sys.md#auditing) `ctypes.create_string_buffer` with arguments `init`, `size`.

**`ctypes.create_unicode_buffer(init, size=None)`**

**`ctypes.create_unicode_buffer(size)`**

> This function creates a mutable unicode character buffer. The returned object is a ctypes array of [`c_wchar`](#ctypes.c_wchar "ctypes.c_wchar").
>
> The function takes the same arguments as [`create_string_buffer()`](#ctypes.create_string_buffer "ctypes.create_string_buffer") except *init* must be a string and *size* counts [`c_wchar`](#ctypes.c_wchar "ctypes.c_wchar").
>
> Raises an [auditing event](sys.md#auditing) `ctypes.create_unicode_buffer` with arguments `init`, `size`.

**`ctypes.DllCanUnloadNow()`**

> This function is a hook which allows implementing in-process COM servers with ctypes. It is called from the DllCanUnloadNow function that the _ctypes extension dll exports.
>
> [Availability](intro.md#availability): Windows

**`ctypes.DllGetClassObject()`**

> This function is a hook which allows implementing in-process COM servers with ctypes. It is called from the DllGetClassObject function that the `_ctypes` extension dll exports.
>
> [Availability](intro.md#availability): Windows

**`ctypes.util.find_library(name)`**

> Try to find a library and return a pathname. *name* is the library name without any prefix like `lib`, suffix like `.so`, `.dylib` or version number (this is the form used for the posix linker option `-l`). If no library can be found, returns `None`.
>
> The exact functionality is system dependent.
>
> See [Finding shared libraries](#ctypes-finding-shared-libraries) for complete documentation.

**`ctypes.util.find_msvcrt()`**

> Returns the filename of the VC runtime library used by Python, and by the extension modules. If the name of the library cannot be determined, `None` is returned.
>
> If you need to free memory, for example, allocated by an extension module with a call to the `free(void *)`, it is important that you use the function in the same library that allocated the memory.
>
> [Availability](intro.md#availability): Windows

**`ctypes.util.dllist()`**

> Try to provide a list of paths of the shared libraries loaded into the current process. These paths are not normalized or processed in any way. The function can raise [`OSError`](../builtins/exceptions.md#OSError "OSError") if the underlying platform APIs fail. The exact functionality is system dependent.
>
> On most platforms, the first element of the list represents the current executable file. It may be an empty string.
>
> [Availability](intro.md#availability): Windows, macOS, iOS, glibc, BSD libc, musl
>
> Added in version 3.14.

**`ctypes.FormatError([code])`**

> Returns a textual description of the error code *code*. If no error code is specified, the last error code is used by calling the Windows API function [`GetLastError()`](#ctypes.GetLastError "ctypes.GetLastError").
>
> [Availability](intro.md#availability): Windows

**`ctypes.GetLastError()`**

> Returns the last error code set by Windows in the calling thread. This function calls the Windows `GetLastError()` function directly, it does not return the ctypes-private copy of the error code.
>
> [Availability](intro.md#availability): Windows

**`ctypes.get_errno()`**

> Returns the current value of the ctypes-private copy of the system [`errno`](errno.md#module-errno "errno: Standard errno system symbols.") variable in the calling thread.
>
> Raises an [auditing event](sys.md#auditing) `ctypes.get_errno` with no arguments.

**`ctypes.get_last_error()`**

> Returns the current value of the ctypes-private copy of the system `LastError` variable in the calling thread.
>
> [Availability](intro.md#availability): Windows
>
> Raises an [auditing event](sys.md#auditing) `ctypes.get_last_error` with no arguments.

**`ctypes.memmove(dst, src, count)`**

> Same as the standard C memmove library function: copies *count* bytes from *src* to *dst*. *dst* and *src* must be integers or ctypes instances that can be converted to pointers.

**`ctypes.memset(dst, c, count)`**

> Same as the standard C memset library function: fills the memory block at address *dst* with *count* bytes of value *c*. *dst* must be an integer specifying an address, or a ctypes instance.

**`ctypes.POINTER(type, /)`**

> Create or return a ctypes pointer type. Pointer types are cached and reused internally, so calling this function repeatedly is cheap. *type* must be a ctypes type.
>
> **CPython implementation detail:** The resulting pointer type is cached in the `__pointer_type__` attribute of *type*. It is possible to set this attribute before the first call to `POINTER` in order to set a custom pointer type. However, doing this is discouraged: manually creating a suitable pointer type is difficult without relying on implementation details that may change in future Python versions.

**`ctypes.pointer(obj, /)`**

> Create a new pointer instance, pointing to *obj*. The returned object is of the type `POINTER(type(obj))`.
>
> Note: If you just want to pass a pointer to an object to a foreign function call, you should use `byref(obj)` which is much faster.

**`ctypes.resize(obj, size)`**

> This function resizes the internal memory buffer of *obj*, which must be an instance of a ctypes type. It is not possible to make the buffer smaller than the native size of the objects type, as given by `sizeof(type(obj))`, but it is possible to enlarge the buffer.

**`ctypes.set_errno(value)`**

> Set the current value of the ctypes-private copy of the system [`errno`](errno.md#module-errno "errno: Standard errno system symbols.") variable in the calling thread to *value* and return the previous value.
>
> Raises an [auditing event](sys.md#auditing) `ctypes.set_errno` with argument `errno`.

**`ctypes.set_last_error(value)`**

> Sets the current value of the ctypes-private copy of the system `LastError` variable in the calling thread to *value* and return the previous value.
>
> [Availability](intro.md#availability): Windows
>
> Raises an [auditing event](sys.md#auditing) `ctypes.set_last_error` with argument `error`.

**`ctypes.sizeof(obj_or_type)`**

> Returns the size in bytes of a ctypes type or instance memory buffer. Does the same as the C `sizeof` operator.

**`ctypes.string_at(ptr, size=-1)`**

> Return the byte string at *void *ptr*. If *size* is specified, it is used as size, otherwise the string is assumed to be zero-terminated.
>
> Raises an [auditing event](sys.md#auditing) `ctypes.string_at` with arguments `ptr`, `size`.

**`ctypes.WinError(code=None, descr=None)`**

> Creates an instance of [`OSError`](../builtins/exceptions.md#OSError "OSError"). If *code* is not specified, [`GetLastError()`](#ctypes.GetLastError "ctypes.GetLastError") is called to determine the error code. If *descr* is not specified, [`FormatError()`](#ctypes.FormatError "ctypes.FormatError") is called to get a textual description of the error.
>
> [Availability](intro.md#availability): Windows
>
> Changed in version 3.3: An instance of [`WindowsError`](../builtins/exceptions.md#WindowsError "WindowsError") used to be created, which is now an alias of [`OSError`](../builtins/exceptions.md#OSError "OSError").

**`ctypes.wstring_at(ptr, size=-1)`**

> Return the wide-character string at *void *ptr*. If *size* is specified, it is used as the number of characters of the string, otherwise the string is assumed to be zero-terminated.
>
> Raises an [auditing event](sys.md#auditing) `ctypes.wstring_at` with arguments `ptr`, `size`.

**`ctypes.memoryview_at(ptr, size, readonly=False)`**

> Return a [`memoryview`](../builtins/stdtypes.md#memoryview "memoryview") object of length *size* that references memory starting at *void *ptr*.
>
> If *readonly* is true, the returned `memoryview` object can not be used to modify the underlying memory. (Changes made by other means will still be reflected in the returned object.)
>
> This function is similar to [`string_at()`](#ctypes.string_at "ctypes.string_at") with the key difference of not making a copy of the specified memory. It is a semantically equivalent (but more efficient) alternative to `memoryview((c_byte * size).from_address(ptr))`. (While [`from_address()`](#ctypes._CData.from_address "ctypes._CData.from_address") only takes integers, *ptr* can also be given as a [`ctypes.POINTER`](#ctypes.POINTER "ctypes.POINTER") or a [`byref()`](#ctypes.byref "ctypes.byref") object.)
>
> Raises an [auditing event](sys.md#auditing) `ctypes.memoryview_at` with arguments `address`, `size`, `readonly`.
>
> Added in version 3.14.

### Data types

**`class ctypes._CData`**

> This non-public class is the common base class of all ctypes data types. Among other things, all ctypes type instances contain a memory block that hold C compatible data; the address of the memory block is returned by the [`addressof()`](#ctypes.addressof "ctypes.addressof") helper function. Another instance variable is exposed as [`_objects`](#ctypes._CData._objects "ctypes._CData._objects"); this contains other Python objects that need to be kept alive in case the memory block contains pointers.
>
> Common methods of ctypes data types, these are all class methods (to be exact, they are methods of the [metaclass](https://docs.python.org/3.14/glossary.html#term-metaclass)):
>
> **`from_buffer(source[, offset])`**
>
> > This method returns a ctypes instance that shares the buffer of the *source* object. The *source* object must support the writeable buffer interface. The optional *offset* parameter specifies an offset into the source buffer in bytes; the default is zero. If the source buffer is not large enough a [`ValueError`](../builtins/exceptions.md#ValueError "ValueError") is raised.
> >
> > Raises an [auditing event](sys.md#auditing) `ctypes.cdata/buffer` with arguments `pointer`, `size`, `offset`.
>
> **`from_buffer_copy(source[, offset])`**
>
> > This method creates a ctypes instance, copying the buffer from the *source* object buffer which must be readable. The optional *offset* parameter specifies an offset into the source buffer in bytes; the default is zero. If the source buffer is not large enough a [`ValueError`](../builtins/exceptions.md#ValueError "ValueError") is raised.
> >
> > Raises an [auditing event](sys.md#auditing) `ctypes.cdata/buffer` with arguments `pointer`, `size`, `offset`.
>
> **`from_address(address)`**
>
> > This method returns a ctypes type instance using the memory specified by *address* which must be an integer.
> >
> > This method, and others that indirectly call this method, raises an [auditing event](sys.md#auditing) `ctypes.cdata` with argument `address`.
>
> **`from_param(obj)`**
>
> > This method adapts *obj* to a ctypes type. It is called with the actual object used in a foreign function call when the type is present in the foreign function’s [`argtypes`](#ctypes._CFuncPtr.argtypes "ctypes._CFuncPtr.argtypes") tuple; it must return an object that can be used as a function call parameter.
> >
> > All ctypes data types have a default implementation of this classmethod that normally returns *obj* if that is an instance of the type. Some types accept other objects as well.
>
> **`in_dll(library, name)`**
>
> > This method returns a ctypes type instance exported by a shared library. *name* is the name of the symbol that exports the data, *library* is the loaded shared library.
>
> Common class variables of ctypes data types:
>
> **`__pointer_type__`**
>
> > The pointer type that was created by calling [`POINTER()`](#ctypes.POINTER "ctypes.POINTER") for corresponding ctypes data type. If a pointer type was not yet created, the attribute is missing.
> >
> > Added in version 3.14.
>
> Common instance variables of ctypes data types:
>
> **`_b_base_`**
>
> > Sometimes ctypes data instances do not own the memory block they contain, instead they share part of the memory block of a base object. The [`_b_base_`](#ctypes._CData._b_base_ "ctypes._CData._b_base_") read-only member is the root ctypes object that owns the memory block.
>
> **`_b_needsfree_`**
>
> > This read-only variable is true when the ctypes data instance has allocated the memory block itself, false otherwise.
>
> **`_objects`**
>
> > This member is either `None` or a dictionary containing Python objects that need to be kept alive so that the memory block contents is kept valid. This object is only exposed for debugging; never modify the contents of this dictionary.

### Fundamental data types

**`class ctypes._SimpleCData`**

> This non-public class is the base class of all fundamental ctypes data types. It is mentioned here because it contains the common attributes of the fundamental ctypes data types. `_SimpleCData` is a subclass of [`_CData`](#ctypes._CData "ctypes._CData"), so it inherits their methods and attributes. ctypes data types that are not and do not contain pointers can now be pickled.
>
> Instances have a single attribute:
>
> **`value`**
>
> > This attribute contains the actual value of the instance. For integer and pointer types, it is an integer, for character types, it is a single character bytes object or string, for character pointer types it is a Python bytes object or string.
> >
> > When the `value` attribute is retrieved from a ctypes instance, usually a new object is returned each time. `ctypes` does *not* implement original object return, always a new object is constructed. The same is true for all other ctypes object instances.
>
> Each subclass has a class attribute:
>
> **`_type_`**
>
> > Class attribute that contains an internal type code, as a single-character string. See [Fundamental data types](#ctypes-fundamental-data-types) for a summary.
> >
> > Types marked * in the summary may be (or always are) aliases of a different `_SimpleCData` subclass, and will not necessarily use the listed type code. For example, if the platform’s long, long long and time_t C types are the same, then [`c_long`](#ctypes.c_long "ctypes.c_long"), [`c_longlong`](#ctypes.c_longlong "ctypes.c_longlong") and [`c_time_t`](#ctypes.c_time_t "ctypes.c_time_t") all refer to a single class, `c_long`, whose [`_type_`](#ctypes._SimpleCData._type_ "ctypes._SimpleCData._type_") code is `'l'`. The `'L'` code will be unused.
> >
> > > **See also:**
> > >
> > > The [`array`](array.md#module-array "array: Space efficient arrays of uniformly typed numeric values.") and [struct](struct.md#format-characters) modules, as well as third-party modules like [numpy](https://numpy.org/doc/stable/reference/arrays.interface.html#object.__array_interface__), use similar – but slightly different – type codes.

Fundamental data types, when returned as foreign function call results, or, for example, by retrieving structure field members or array items, are transparently converted to native Python types. In other words, if a foreign function has a [`restype`](#ctypes._CFuncPtr.restype "ctypes._CFuncPtr.restype") of [`c_char_p`](#ctypes.c_char_p "ctypes.c_char_p"), you will always receive a Python bytes object, *not* a `c_char_p` instance.

Subclasses of fundamental data types do *not* inherit this behavior. So, if a foreign functions `restype` is a subclass of [`c_void_p`](#ctypes.c_void_p "ctypes.c_void_p"), you will receive an instance of this subclass from the function call. Of course, you can get the value of the pointer by accessing the `value` attribute.

These are the fundamental ctypes data types:

**`class ctypes.c_byte`**

> Represents the C signed char datatype, and interprets the value as small integer. The constructor accepts an optional integer initializer; no overflow checking is done.

**`class ctypes.c_char`**

> Represents the C char datatype, and interprets the value as a single character. The constructor accepts an optional string initializer, the length of the string must be exactly one character.

**`class ctypes.c_char_p`**

> Represents the C char* datatype when it points to a zero-terminated string. For a general character pointer that may also point to binary data, `POINTER(c_char)` must be used. The constructor accepts an integer address, or a bytes object.

**`class ctypes.c_double`**

> Represents the C double datatype. The constructor accepts an optional float initializer.

**`class ctypes.c_longdouble`**

> Represents the C long double datatype. The constructor accepts an optional float initializer. On platforms where `sizeof(long double) == sizeof(double)` it is an alias to [`c_double`](#ctypes.c_double "ctypes.c_double").

**`class ctypes.c_float`**

> Represents the C float datatype. The constructor accepts an optional float initializer.

**`class ctypes.c_double_complex`**

> Represents the C double complex datatype, if available. The constructor accepts an optional [`complex`](../builtins/functions.md#complex "complex") initializer.
>
> Added in version 3.14.

**`class ctypes.c_float_complex`**

> Represents the C float complex datatype, if available. The constructor accepts an optional [`complex`](../builtins/functions.md#complex "complex") initializer.
>
> Added in version 3.14.

**`class ctypes.c_longdouble_complex`**

> Represents the C long double complex datatype, if available. The constructor accepts an optional [`complex`](../builtins/functions.md#complex "complex") initializer.
>
> Added in version 3.14.

**`class ctypes.c_int`**

> Represents the C signed int datatype. The constructor accepts an optional integer initializer; no overflow checking is done. On platforms where `sizeof(int) == sizeof(long)` it is an alias to [`c_long`](#ctypes.c_long "ctypes.c_long").

**`class ctypes.c_int8`**

> Represents the C 8-bit signed int datatype. It is an alias for [`c_byte`](#ctypes.c_byte "ctypes.c_byte").

**`class ctypes.c_int16`**

> Represents the C 16-bit signed int datatype. Usually an alias for [`c_short`](#ctypes.c_short "ctypes.c_short").

**`class ctypes.c_int32`**

> Represents the C 32-bit signed int datatype. Usually an alias for [`c_int`](#ctypes.c_int "ctypes.c_int").

**`class ctypes.c_int64`**

> Represents the C 64-bit signed int datatype. Usually an alias for [`c_longlong`](#ctypes.c_longlong "ctypes.c_longlong").

**`class ctypes.c_long`**

> Represents the C signed long datatype. The constructor accepts an optional integer initializer; no overflow checking is done.

**`class ctypes.c_longlong`**

> Represents the C signed long long datatype. The constructor accepts an optional integer initializer; no overflow checking is done. On platforms where `sizeof(long long) == sizeof(long)` it is an alias to [`c_long`](#ctypes.c_long "ctypes.c_long").

**`class ctypes.c_short`**

> Represents the C signed short datatype. The constructor accepts an optional integer initializer; no overflow checking is done.

**`class ctypes.c_size_t`**

> Represents the C `size_t` datatype. Usually an alias for another unsigned integer type.

**`class ctypes.c_ssize_t`**

> Represents the [`Py_ssize_t`](https://docs.python.org/3.14/c-api/intro.html#c.Py_ssize_t "Py_ssize_t") datatype. This is a signed version of `size_t`; that is, the POSIX `ssize_t` type. Usually an alias for another integer type.
>
> Added in version 3.2.

**`class ctypes.c_time_t`**

> Represents the C `time_t` datatype. Usually an alias for another integer type.
>
> Added in version 3.12.

**`class ctypes.c_ubyte`**

> Represents the C unsigned char datatype, it interprets the value as small integer. The constructor accepts an optional integer initializer; no overflow checking is done.

**`class ctypes.c_uint`**

> Represents the C unsigned int datatype. The constructor accepts an optional integer initializer; no overflow checking is done. On platforms where `sizeof(int) == sizeof(long)` it is an alias for [`c_ulong`](#ctypes.c_ulong "ctypes.c_ulong").

**`class ctypes.c_uint8`**

> Represents the C 8-bit unsigned int datatype. It is an alias for [`c_ubyte`](#ctypes.c_ubyte "ctypes.c_ubyte").

**`class ctypes.c_uint16`**

> Represents the C 16-bit unsigned int datatype. Usually an alias for [`c_ushort`](#ctypes.c_ushort "ctypes.c_ushort").

**`class ctypes.c_uint32`**

> Represents the C 32-bit unsigned int datatype. Usually an alias for [`c_uint`](#ctypes.c_uint "ctypes.c_uint").

**`class ctypes.c_uint64`**

> Represents the C 64-bit unsigned int datatype. Usually an alias for [`c_ulonglong`](#ctypes.c_ulonglong "ctypes.c_ulonglong").

**`class ctypes.c_ulong`**

> Represents the C unsigned long datatype. The constructor accepts an optional integer initializer; no overflow checking is done.

**`class ctypes.c_ulonglong`**

> Represents the C unsigned long long datatype. The constructor accepts an optional integer initializer; no overflow checking is done. On platforms where `sizeof(long long) == sizeof(long)` it is an alias to [`c_long`](#ctypes.c_long "ctypes.c_long").

**`class ctypes.c_ushort`**

> Represents the C unsigned short datatype. The constructor accepts an optional integer initializer; no overflow checking is done.

**`class ctypes.c_void_p`**

> Represents the C void* type. The value is represented as integer. The constructor accepts an optional integer initializer.

**`class ctypes.c_wchar`**

> Represents the C `wchar_t` datatype, and interprets the value as a single character unicode string. The constructor accepts an optional string initializer, the length of the string must be exactly one character.

**`class ctypes.c_wchar_p`**

> Represents the C wchar_t* datatype, which must be a pointer to a zero-terminated wide character string. The constructor accepts an integer address, or a string.

**`class ctypes.c_bool`**

> Represent the C bool datatype (more accurately, _Bool from C99). Its value can be `True` or `False`, and the constructor accepts any object that has a truth value.

**`class ctypes.HRESULT`**

> Represents a `HRESULT` value, which contains success or error information for a function or method call.
>
> [Availability](intro.md#availability): Windows

**`class ctypes.py_object`**

> Represents the C [PyObject](https://docs.python.org/3.14/c-api/structures.html#c.PyObject "PyObject")* datatype. Calling this without an argument creates a `NULL` PyObject* pointer.
>
> Changed in version 3.14: `py_object` is now a [generic type](https://docs.python.org/3.14/glossary.html#term-generic-type).

### Windows data types

**Source code:** [Lib/ctypes/wintypes.py](https://github.com/python/cpython/tree/3.14/Lib/ctypes/wintypes.py)

The `ctypes.wintypes` module provides types for use with Windows APIs. Most are aliases for types defined in `ctypes`. See Microsoft’s [Windows data types](https://learn.microsoft.com/en-us/windows/win32/winprog/windows-data-types) documentation for the corresponding C definitions. On non-Windows platforms, the sizes and layouts of these types may differ from their Windows counterparts.

Changed in version 3.14: Added [`HCONV`](#ctypes.wintypes.HCONV "ctypes.wintypes.HCONV"), [`HCONVLIST`](#ctypes.wintypes.HCONVLIST "ctypes.wintypes.HCONVLIST"), [`HCURSOR`](#ctypes.wintypes.HCURSOR "ctypes.wintypes.HCURSOR"), [`HDDEDATA`](#ctypes.wintypes.HDDEDATA "ctypes.wintypes.HDDEDATA"), [`HDROP`](#ctypes.wintypes.HDROP "ctypes.wintypes.HDROP"), [`HFILE`](#ctypes.wintypes.HFILE "ctypes.wintypes.HFILE"), [`HRESULT`](#ctypes.wintypes.HRESULT "ctypes.wintypes.HRESULT"), and [`HSZ`](#ctypes.wintypes.HSZ "ctypes.wintypes.HSZ").

For example:

``` pycon
>>> from ctypes import POINTER
>>> from ctypes.wintypes import LPRECT, RECT, SHORT
>>> SHORT(-1).value
-1
>>> rect = RECT(0, 0, 100, 50)
>>> rect.right, rect.bottom
(100, 50)
>>> LPRECT is POINTER(RECT)
True
```

#### Simple types

The following names are aliases for fundamental `ctypes` types:

| Windows types | `ctypes` type |
|---|---|
| **`class ctypes.wintypes.BYTE`**<br>**`class ctypes.wintypes.BOOLEAN`** | [`c_ubyte`](#ctypes.c_ubyte "ctypes.c_ubyte") |
| **`class ctypes.wintypes.CHAR`** | [`c_char`](#ctypes.c_char "ctypes.c_char") |
| **`class ctypes.wintypes.WCHAR`** | [`c_wchar`](#ctypes.c_wchar "ctypes.c_wchar") |
| **`class ctypes.wintypes.WORD`**<br>**`class ctypes.wintypes.USHORT`**<br>**`class ctypes.wintypes.ATOM`**<br>**`class ctypes.wintypes.LANGID`** | [`c_ushort`](#ctypes.c_ushort "ctypes.c_ushort") |
| **`class ctypes.wintypes.DWORD`**<br>**`class ctypes.wintypes.ULONG`**<br>**`class ctypes.wintypes.COLORREF`**<br>**`class ctypes.wintypes.LCID`**<br>**`class ctypes.wintypes.LCTYPE`**<br>**`class ctypes.wintypes.LGRPID`** | [`c_ulong`](#ctypes.c_ulong "ctypes.c_ulong") |
| **`class ctypes.wintypes.BOOL`**<br>**`class ctypes.wintypes.LONG`**<br>**`class ctypes.wintypes.HRESULT`** | [`c_long`](#ctypes.c_long "ctypes.c_long") |
| **`class ctypes.wintypes.INT`**<br>**`class ctypes.wintypes.HFILE`** | [`c_int`](#ctypes.c_int "ctypes.c_int") |
| **`class ctypes.wintypes.UINT`** | [`c_uint`](#ctypes.c_uint "ctypes.c_uint") |
| **`class ctypes.wintypes.SHORT`** | [`c_short`](#ctypes.c_short "ctypes.c_short") |
| **`class ctypes.wintypes.DOUBLE`** | [`c_double`](#ctypes.c_double "ctypes.c_double") |
| **`class ctypes.wintypes.FLOAT`** | [`c_float`](#ctypes.c_float "ctypes.c_float") |
| **`class ctypes.wintypes.LARGE_INTEGER`** | [`c_longlong`](#ctypes.c_longlong "ctypes.c_longlong") |
| **`class ctypes.wintypes.ULARGE_INTEGER`** | [`c_ulonglong`](#ctypes.c_ulonglong "ctypes.c_ulonglong") |
| **`class ctypes.wintypes.LPCSTR`**<br>**`class ctypes.wintypes.LPSTR`** | [`c_char_p`](#ctypes.c_char_p "ctypes.c_char_p") |
| **`class ctypes.wintypes.LPCOLESTR`**<br>**`class ctypes.wintypes.LPOLESTR`**<br>**`class ctypes.wintypes.OLESTR`**<br>**`class ctypes.wintypes.LPCWSTR`**<br>**`class ctypes.wintypes.LPWSTR`** | [`c_wchar_p`](#ctypes.c_wchar_p "ctypes.c_wchar_p") |
| **`class ctypes.wintypes.LPCVOID`**<br>**`class ctypes.wintypes.LPVOID`** | [`c_void_p`](#ctypes.c_void_p "ctypes.c_void_p") |

[`LARGE_INTEGER`](#ctypes.wintypes.LARGE_INTEGER "ctypes.wintypes.LARGE_INTEGER") and [`ULARGE_INTEGER`](#ctypes.wintypes.ULARGE_INTEGER "ctypes.wintypes.ULARGE_INTEGER") expose an integer `value` attribute, with no `LowPart`, `HighPart`, or `QuadPart` fields.

**`class ctypes.wintypes.WPARAM`**

> An unsigned integer type with the same size as [`c_void_p`](#ctypes.c_void_p "ctypes.c_void_p").

**`class ctypes.wintypes.LPARAM`**

> A signed integer type with the same size as [`c_void_p`](#ctypes.c_void_p "ctypes.c_void_p").

**`class ctypes.wintypes.VARIANT_BOOL`**

> A 16-bit Boolean type whose `value` attribute is a Python [`bool`](../builtins/functions.md#bool "bool"). Assigning to `value` stores `-1` for a true value and `0` for a false value.

#### Handle types

**`class ctypes.wintypes.HANDLE`**

> An alias for [`c_void_p`](#ctypes.c_void_p "ctypes.c_void_p"), used to represent Windows handles.

**`class ctypes.wintypes.HACCEL`**

**`class ctypes.wintypes.HBITMAP`**

**`class ctypes.wintypes.HBRUSH`**

**`class ctypes.wintypes.HCOLORSPACE`**

**`class ctypes.wintypes.HCONV`**

**`class ctypes.wintypes.HCONVLIST`**

**`class ctypes.wintypes.HCURSOR`**

**`class ctypes.wintypes.HDC`**

**`class ctypes.wintypes.HDDEDATA`**

**`class ctypes.wintypes.HDESK`**

**`class ctypes.wintypes.HDROP`**

**`class ctypes.wintypes.HDWP`**

**`class ctypes.wintypes.HENHMETAFILE`**

**`class ctypes.wintypes.HFONT`**

**`class ctypes.wintypes.HGDIOBJ`**

**`class ctypes.wintypes.HGLOBAL`**

**`class ctypes.wintypes.HHOOK`**

**`class ctypes.wintypes.HICON`**

**`class ctypes.wintypes.HINSTANCE`**

**`class ctypes.wintypes.HKEY`**

**`class ctypes.wintypes.HKL`**

**`class ctypes.wintypes.HLOCAL`**

**`class ctypes.wintypes.HMENU`**

**`class ctypes.wintypes.HMETAFILE`**

**`class ctypes.wintypes.HMODULE`**

**`class ctypes.wintypes.HMONITOR`**

**`class ctypes.wintypes.HPALETTE`**

**`class ctypes.wintypes.HPEN`**

**`class ctypes.wintypes.HRGN`**

**`class ctypes.wintypes.HRSRC`**

**`class ctypes.wintypes.HSTR`**

**`class ctypes.wintypes.HSZ`**

**`class ctypes.wintypes.HTASK`**

**`class ctypes.wintypes.HWINSTA`**

**`class ctypes.wintypes.HWND`**

**`class ctypes.wintypes.SC_HANDLE`**

**`class ctypes.wintypes.SERVICE_STATUS_HANDLE`**

> Aliases for [`HANDLE`](#ctypes.wintypes.HANDLE "ctypes.wintypes.HANDLE") for use with specific Windows APIs. [`HFILE`](#ctypes.wintypes.HFILE "ctypes.wintypes.HFILE") is an alias for [`INT`](#ctypes.wintypes.INT "ctypes.wintypes.INT") and is listed among the simple types above.

#### Structures

The following types are subclasses of [`ctypes.Structure`](#ctypes.Structure "ctypes.Structure").

**`class ctypes.wintypes.RECT`**

**`class ctypes.wintypes.RECTL`**

**`class ctypes.wintypes.tagRECT`**

> A rectangle with `left`, `top`, `right`, and `bottom` fields, all of type [`LONG`](#ctypes.wintypes.LONG "ctypes.wintypes.LONG").

**`class ctypes.wintypes.SMALL_RECT`**

> A rectangle with `Left`, `Top`, `Right`, and `Bottom` fields, all of type [`SHORT`](#ctypes.wintypes.SHORT "ctypes.wintypes.SHORT").

**`class ctypes.wintypes.POINT`**

**`class ctypes.wintypes.POINTL`**

**`class ctypes.wintypes.tagPOINT`**

> A point with `x` and `y` fields, both of type [`LONG`](#ctypes.wintypes.LONG "ctypes.wintypes.LONG").

**`class ctypes.wintypes.SIZE`**

**`class ctypes.wintypes.SIZEL`**

**`class ctypes.wintypes.tagSIZE`**

> Dimensions with `cx` and `cy` fields, both of type [`LONG`](#ctypes.wintypes.LONG "ctypes.wintypes.LONG").

**`class ctypes.wintypes.FILETIME`**

> A file time with `dwLowDateTime` and `dwHighDateTime` fields, both of type [`DWORD`](#ctypes.wintypes.DWORD "ctypes.wintypes.DWORD").

**`class ctypes.wintypes.MSG`**

**`class ctypes.wintypes.tagMSG`**

> A Windows message with the following fields:
>
> | Field | Type |
|---|---|
| `hWnd` | [`HWND`](#ctypes.wintypes.HWND "ctypes.wintypes.HWND") |
| `message` | [`UINT`](#ctypes.wintypes.UINT "ctypes.wintypes.UINT") |
| `wParam` | [`WPARAM`](#ctypes.wintypes.WPARAM "ctypes.wintypes.WPARAM") |
| `lParam` | [`LPARAM`](#ctypes.wintypes.LPARAM "ctypes.wintypes.LPARAM") |
| `time` | [`DWORD`](#ctypes.wintypes.DWORD "ctypes.wintypes.DWORD") |
| `pt` | [`POINT`](#ctypes.wintypes.POINT "ctypes.wintypes.POINT") |

**`class ctypes.wintypes.WIN32_FIND_DATAA`**

**`class ctypes.wintypes.WIN32_FIND_DATAW`**

> Structures used by Windows file-search functions, with the following fields. `WIN32_FIND_DATAA` uses [`CHAR`](#ctypes.wintypes.CHAR "ctypes.wintypes.CHAR") for its file names, and `WIN32_FIND_DATAW` uses [`WCHAR`](#ctypes.wintypes.WCHAR "ctypes.wintypes.WCHAR").
>
> | Fields | Type |
|---|---|
| `dwFileAttributes` | [`DWORD`](#ctypes.wintypes.DWORD "ctypes.wintypes.DWORD") |
| `ftCreationTime`, `ftLastAccessTime`, `ftLastWriteTime` | [`FILETIME`](#ctypes.wintypes.FILETIME "ctypes.wintypes.FILETIME") |
| `nFileSizeHigh`, `nFileSizeLow` | [`DWORD`](#ctypes.wintypes.DWORD "ctypes.wintypes.DWORD") |
| `dwReserved0`, `dwReserved1` | [`DWORD`](#ctypes.wintypes.DWORD "ctypes.wintypes.DWORD") |
| `cFileName` | An array of [`MAX_PATH`](#ctypes.wintypes.MAX_PATH "ctypes.wintypes.MAX_PATH") characters |
| `cAlternateFileName` | An array of 14 characters |

#### Pointer types

The following names are aliases for `ctypes.POINTER(T)`, where *T* is the type in the second column:

| Pointer types | Referenced type |
|---|---|
| **`class ctypes.wintypes.LPBOOL`**<br>**`class ctypes.wintypes.PBOOL`** | [`BOOL`](#ctypes.wintypes.BOOL "ctypes.wintypes.BOOL") |
| **`class ctypes.wintypes.PBOOLEAN`** | [`BOOLEAN`](#ctypes.wintypes.BOOLEAN "ctypes.wintypes.BOOLEAN") |
| **`class ctypes.wintypes.LPBYTE`**<br>**`class ctypes.wintypes.PBYTE`** | [`BYTE`](#ctypes.wintypes.BYTE "ctypes.wintypes.BYTE") |
| **`class ctypes.wintypes.PCHAR`** | [`CHAR`](#ctypes.wintypes.CHAR "ctypes.wintypes.CHAR") |
| **`class ctypes.wintypes.LPCOLORREF`** | [`COLORREF`](#ctypes.wintypes.COLORREF "ctypes.wintypes.COLORREF") |
| **`class ctypes.wintypes.LPDWORD`**<br>**`class ctypes.wintypes.PDWORD`** | [`DWORD`](#ctypes.wintypes.DWORD "ctypes.wintypes.DWORD") |
| **`class ctypes.wintypes.LPFILETIME`**<br>**`class ctypes.wintypes.PFILETIME`** | [`FILETIME`](#ctypes.wintypes.FILETIME "ctypes.wintypes.FILETIME") |
| **`class ctypes.wintypes.PFLOAT`** | [`FLOAT`](#ctypes.wintypes.FLOAT "ctypes.wintypes.FLOAT") |
| **`class ctypes.wintypes.LPHANDLE`**<br>**`class ctypes.wintypes.PHANDLE`** | [`HANDLE`](#ctypes.wintypes.HANDLE "ctypes.wintypes.HANDLE") |
| **`class ctypes.wintypes.PHKEY`** | [`HKEY`](#ctypes.wintypes.HKEY "ctypes.wintypes.HKEY") |
| **`class ctypes.wintypes.LPHKL`** | [`HKL`](#ctypes.wintypes.HKL "ctypes.wintypes.HKL") |
| **`class ctypes.wintypes.LPINT`**<br>**`class ctypes.wintypes.PINT`** | [`INT`](#ctypes.wintypes.INT "ctypes.wintypes.INT") |
| **`class ctypes.wintypes.PLARGE_INTEGER`** | [`LARGE_INTEGER`](#ctypes.wintypes.LARGE_INTEGER "ctypes.wintypes.LARGE_INTEGER") |
| **`class ctypes.wintypes.PLCID`** | [`LCID`](#ctypes.wintypes.LCID "ctypes.wintypes.LCID") |
| **`class ctypes.wintypes.LPLONG`**<br>**`class ctypes.wintypes.PLONG`** | [`LONG`](#ctypes.wintypes.LONG "ctypes.wintypes.LONG") |
| **`class ctypes.wintypes.LPMSG`**<br>**`class ctypes.wintypes.PMSG`** | [`MSG`](#ctypes.wintypes.MSG "ctypes.wintypes.MSG") |
| **`class ctypes.wintypes.LPPOINT`**<br>**`class ctypes.wintypes.PPOINT`** | [`POINT`](#ctypes.wintypes.POINT "ctypes.wintypes.POINT") |
| **`class ctypes.wintypes.PPOINTL`** | [`POINTL`](#ctypes.wintypes.POINTL "ctypes.wintypes.POINTL") |
| **`class ctypes.wintypes.LPRECT`**<br>**`class ctypes.wintypes.PRECT`** | [`RECT`](#ctypes.wintypes.RECT "ctypes.wintypes.RECT") |
| **`class ctypes.wintypes.LPRECTL`**<br>**`class ctypes.wintypes.PRECTL`** | [`RECTL`](#ctypes.wintypes.RECTL "ctypes.wintypes.RECTL") |
| **`class ctypes.wintypes.LPSC_HANDLE`** | [`SC_HANDLE`](#ctypes.wintypes.SC_HANDLE "ctypes.wintypes.SC_HANDLE") |
| **`class ctypes.wintypes.PSHORT`** | [`SHORT`](#ctypes.wintypes.SHORT "ctypes.wintypes.SHORT") |
| **`class ctypes.wintypes.LPSIZE`**<br>**`class ctypes.wintypes.PSIZE`** | [`SIZE`](#ctypes.wintypes.SIZE "ctypes.wintypes.SIZE") |
| **`class ctypes.wintypes.LPSIZEL`**<br>**`class ctypes.wintypes.PSIZEL`** | [`SIZEL`](#ctypes.wintypes.SIZEL "ctypes.wintypes.SIZEL") |
| **`class ctypes.wintypes.PSMALL_RECT`** | [`SMALL_RECT`](#ctypes.wintypes.SMALL_RECT "ctypes.wintypes.SMALL_RECT") |
| **`class ctypes.wintypes.LPUINT`**<br>**`class ctypes.wintypes.PUINT`** | [`UINT`](#ctypes.wintypes.UINT "ctypes.wintypes.UINT") |
| **`class ctypes.wintypes.PULARGE_INTEGER`** | [`ULARGE_INTEGER`](#ctypes.wintypes.ULARGE_INTEGER "ctypes.wintypes.ULARGE_INTEGER") |
| **`class ctypes.wintypes.PULONG`** | [`ULONG`](#ctypes.wintypes.ULONG "ctypes.wintypes.ULONG") |
| **`class ctypes.wintypes.PUSHORT`** | [`USHORT`](#ctypes.wintypes.USHORT "ctypes.wintypes.USHORT") |
| **`class ctypes.wintypes.PWCHAR`** | [`WCHAR`](#ctypes.wintypes.WCHAR "ctypes.wintypes.WCHAR") |
| **`class ctypes.wintypes.LPWIN32_FIND_DATAA`**<br>**`class ctypes.wintypes.PWIN32_FIND_DATAA`** | [`WIN32_FIND_DATAA`](#ctypes.wintypes.WIN32_FIND_DATAA "ctypes.wintypes.WIN32_FIND_DATAA") |
| **`class ctypes.wintypes.LPWIN32_FIND_DATAW`**<br>**`class ctypes.wintypes.PWIN32_FIND_DATAW`** | [`WIN32_FIND_DATAW`](#ctypes.wintypes.WIN32_FIND_DATAW "ctypes.wintypes.WIN32_FIND_DATAW") |
| **`class ctypes.wintypes.LPWORD`**<br>**`class ctypes.wintypes.PWORD`** | [`WORD`](#ctypes.wintypes.WORD "ctypes.wintypes.WORD") |

#### Constants and functions

**`ctypes.wintypes.MAX_PATH`**

> The value `260`, used as the size of the file-name arrays in [`WIN32_FIND_DATAA`](#ctypes.wintypes.WIN32_FIND_DATAA "ctypes.wintypes.WIN32_FIND_DATAA") and [`WIN32_FIND_DATAW`](#ctypes.wintypes.WIN32_FIND_DATAW "ctypes.wintypes.WIN32_FIND_DATAW").

**`ctypes.wintypes.RGB(red, green, blue)`**

> Return a [`COLORREF`](#ctypes.wintypes.COLORREF "ctypes.wintypes.COLORREF") value as a Python integer. The *red*, *green*, and *blue* arguments are integers from `0` to `255`, specifying the intensity of each color component:
>
> ``` pycon
> >>> from ctypes.wintypes import RGB
> >>> hex(RGB(255, 128, 0))
> '0x80ff'
> ```

### Structured data types

**`class ctypes.Union(*args, **kw)`**

> Abstract base class for unions in native byte order.
>
> Unions share common attributes and behavior with structures; see [`Structure`](#ctypes.Structure "ctypes.Structure") documentation for details.

**`class ctypes.BigEndianUnion(*args, **kw)`**

> Abstract base class for unions in *big endian* byte order.
>
> Added in version 3.11.

**`class ctypes.LittleEndianUnion(*args, **kw)`**

> Abstract base class for unions in *little endian* byte order.
>
> Added in version 3.11.

**`class ctypes.BigEndianStructure(*args, **kw)`**

> Abstract base class for structures in *big endian* byte order.

**`class ctypes.LittleEndianStructure(*args, **kw)`**

> Abstract base class for structures in *little endian* byte order.

Structures and unions with non-native byte order cannot contain pointer type fields, or any other data types containing pointer type fields.

**`class ctypes.Structure(*args, **kw)`**

> Abstract base class for structures in *native* byte order.
>
> Concrete structure and union types must be created by subclassing one of these types, and at least define a [`_fields_`](#ctypes.Structure._fields_ "ctypes.Structure._fields_") class variable. `ctypes` will create [descriptor](https://docs.python.org/3.14/glossary.html#term-descriptor)s which allow reading and writing the fields by direct attribute accesses. These are the
>
> **`_fields_`**
>
> > A sequence defining the structure fields. The items must be 2-tuples or 3-tuples. The first item is the name of the field, the second item specifies the type of the field; it can be any ctypes data type.
> >
> > For integer type fields like [`c_int`](#ctypes.c_int "ctypes.c_int"), a third optional item can be given. It must be a small positive integer defining the bit width of the field.
> >
> > Field names must be unique within one structure or union. This is not checked, only one field can be accessed when names are repeated.
> >
> > It is possible to define the [`_fields_`](#ctypes.Structure._fields_ "ctypes.Structure._fields_") class variable *after* the class statement that defines the Structure subclass, this allows creating data types that directly or indirectly reference themselves:
> >
> > ``` python
> > class List(Structure):
> >     pass
> > List._fields_ = [("pnext", POINTER(List)),
> >                  ...
> >                 ]
> > ```
> >
> > The `_fields_` class variable can only be set once. Later assignments will raise an [`AttributeError`](../builtins/exceptions.md#AttributeError "AttributeError").
> >
> > Additionally, the `_fields_` class variable must be defined before the structure or union type is first used: an instance or subclass is created, [`sizeof()`](#ctypes.sizeof "ctypes.sizeof") is called on it, and so on. Later assignments to `_fields_` will raise an [`AttributeError`](../builtins/exceptions.md#AttributeError "AttributeError"). If `_fields_` has not been set before such use, the structure or union will have no own fields, as if `_fields_` was empty.
> >
> > Sub-subclasses of structure types inherit the fields of the base class plus the [`_fields_`](#ctypes.Structure._fields_ "ctypes.Structure._fields_") defined in the sub-subclass, if any.
>
> **`_pack_`**
>
> > An optional small integer that allows overriding the alignment of structure fields in the instance.
> >
> > This is only implemented for the MSVC-compatible memory layout (see [`_layout_`](#ctypes.Structure._layout_ "ctypes.Structure._layout_")).
> >
> > Setting `_pack_` to 0 is the same as not setting it at all. Otherwise, the value must be a positive power of two. The effect is equivalent to `#pragma pack(N)` in C, except `ctypes` may allow larger *n* than what the compiler accepts.
> >
> > `_pack_` must already be defined when [`_fields_`](#ctypes.Structure._fields_ "ctypes.Structure._fields_") is assigned, otherwise it will have no effect.
> >
> > Deprecated since version 3.14, will be removed in version 3.19: For historical reasons, if `_pack_` is non-zero, the MSVC-compatible layout will be used by default. On non-Windows platforms, this default is deprecated and is slated to become an error in Python 3.19. If it is intended, set [`_layout_`](#ctypes.Structure._layout_ "ctypes.Structure._layout_") to `'ms'` explicitly.
>
> **`_align_`**
>
> > An optional small integer that allows increasing the alignment of the structure when being packed or unpacked to/from memory.
> >
> > The value must not be negative. The effect is equivalent to `__attribute__((aligned(N)))` on GCC or `#pragma align(N)` on MSVC, except `ctypes` may allow values that the compiler would reject.
> >
> > `_align_` can only *increase* a structure’s alignment requirements. Setting it to 0 or 1 has no effect.
> >
> > Using values that are not powers of two is discouraged and may lead to surprising behavior.
> >
> > `_align_` must already be defined when [`_fields_`](#ctypes.Structure._fields_ "ctypes.Structure._fields_") is assigned, otherwise it will have no effect.
> >
> > Added in version 3.13.
>
> **`_layout_`**
>
> > An optional string naming the struct/union layout. It can currently be set to:
> >
> > - `"ms"`: the layout used by the Microsoft compiler (MSVC). On GCC and Clang, this layout can be selected with `__attribute__((ms_struct))`.
> >
> > - `"gcc-sysv"`: the layout used by GCC with the System V or “SysV-like” data model, as used on Linux and macOS. With this layout, [`_pack_`](#ctypes.Structure._pack_ "ctypes.Structure._pack_") must be unset or zero.
> >
> > If not set explicitly, `ctypes` will use a default that matches the platform conventions. This default may change in future Python releases (for example, when a new platform gains official support, or when a difference between similar platforms is found). Currently the default will be:
> >
> > - On Windows: `"ms"`
> >
> > - When [`_pack_`](#ctypes.Structure._pack_ "ctypes.Structure._pack_") is specified: `"ms"`. (This is deprecated; see `_pack_` documentation.)
> >
> > - Otherwise: `"gcc-sysv"`
> >
> > `_layout_` must already be defined when [`_fields_`](#ctypes.Structure._fields_ "ctypes.Structure._fields_") is assigned, otherwise it will have no effect.
> >
> > Added in version 3.14.
>
> **`_anonymous_`**
>
> > An optional sequence that lists the names of unnamed (anonymous) fields. [`_anonymous_`](#ctypes.Structure._anonymous_ "ctypes.Structure._anonymous_") must be already defined when [`_fields_`](#ctypes.Structure._fields_ "ctypes.Structure._fields_") is assigned, otherwise it will have no effect.
> >
> > The fields listed in this variable must be structure or union type fields. `ctypes` will create descriptors in the structure type that allows accessing the nested fields directly, without the need to create the structure or union field.
> >
> > Here is an example type (Windows):
> >
> > ``` python
> > class _U(Union):
> >     _fields_ = [("lptdesc", POINTER(TYPEDESC)),
> >                 ("lpadesc", POINTER(ARRAYDESC)),
> >                 ("hreftype", HREFTYPE)]
> >
> > class TYPEDESC(Structure):
> >     _anonymous_ = ("u",)
> >     _fields_ = [("u", _U),
> >                 ("vt", VARTYPE)]
> > ```
> >
> > The `TYPEDESC` structure describes a COM data type, the `vt` field specifies which one of the union fields is valid. Since the `u` field is defined as anonymous field, it is now possible to access the members directly off the TYPEDESC instance. `td.lptdesc` and `td.u.lptdesc` are equivalent, but the former is faster since it does not need to create a temporary union instance:
> >
> > ``` python
> > td = TYPEDESC()
> > td.vt = VT_PTR
> > td.lptdesc = POINTER(some_type)
> > td.u.lptdesc = POINTER(some_type)
> > ```
>
> It is possible to define sub-subclasses of structures, they inherit the fields of the base class. If the subclass definition has a separate [`_fields_`](#ctypes.Structure._fields_ "ctypes.Structure._fields_") variable, the fields specified in this are appended to the fields of the base class.
>
> Structure and union constructors accept both positional and keyword arguments. Positional arguments are used to initialize member fields in the same order as they are appear in [`_fields_`](#ctypes.Structure._fields_ "ctypes.Structure._fields_"). Keyword arguments in the constructor are interpreted as attribute assignments, so they will initialize `_fields_` with the same name, or create new attributes for names not present in `_fields_`.

**`class ctypes.CField(*args, **kw)`**

> Descriptor for fields of a [`Structure`](#ctypes.Structure "ctypes.Structure") and [`Union`](#ctypes.Union "ctypes.Union"). For example:
>
> ``` pycon
> >>> class Color(Structure):
> ...     _fields_ = (
> ...         ('red', c_uint8),
> ...         ('green', c_uint8),
> ...         ('blue', c_uint8),
> ...         ('intense', c_bool, 1),
> ...         ('blinking', c_bool, 1),
> ...    )
> ...
> >>> Color.red
> <ctypes.CField 'red' type=c_ubyte, ofs=0, size=1>
> >>> Color.green.type
> <class 'ctypes.c_ubyte'>
> >>> Color.blue.byte_offset
> 2
> >>> Color.intense
> <ctypes.CField 'intense' type=c_bool, ofs=3, bit_size=1, bit_offset=0>
> >>> Color.blinking.bit_offset
> 1
> ```
>
> All attributes are read-only.
>
> `CField` objects are created via [`_fields_`](#ctypes.Structure._fields_ "ctypes.Structure._fields_"); do not instantiate the class directly.
>
> Added in version 3.14: Previously, descriptors only had `offset` and `size` attributes and a readable string representation; the `CField` class was not available directly.
>
> **`name`**
>
> > Name of the field, as a string.
>
> **`type`**
>
> > Type of the field, as a [ctypes class](#ctypes-data-types).
>
> **`offset`**
>
> **`byte_offset`**
>
> > Offset of the field, in bytes.
> >
> > For bitfields, this is the offset of the underlying byte-aligned *storage unit*; see [`bit_offset`](#ctypes.CField.bit_offset "ctypes.CField.bit_offset").
>
> **`byte_size`**
>
> > Size of the field, in bytes.
> >
> > For bitfields, this is the size of the underlying *storage unit*. Typically, it has the same size as the bitfield’s type.
>
> **`size`**
>
> > For non-bitfields, equivalent to [`byte_size`](#ctypes.CField.byte_size "ctypes.CField.byte_size").
> >
> > For bitfields, this contains a backwards-compatible bit-packed value that combines [`bit_size`](#ctypes.CField.bit_size "ctypes.CField.bit_size") and [`bit_offset`](#ctypes.CField.bit_offset "ctypes.CField.bit_offset"). Prefer using the explicit attributes instead.
>
> **`is_bitfield`**
>
> > True if this is a bitfield.
>
> **`bit_offset`**
>
> **`bit_size`**
>
> > The location of a bitfield within its *storage unit*, that is, within [`byte_size`](#ctypes.CField.byte_size "ctypes.CField.byte_size") bytes of memory starting at [`byte_offset`](#ctypes.CField.byte_offset "ctypes.CField.byte_offset").
> >
> > To get the field’s value, read the storage unit as an integer, [shift left](../reference/expressions.md#shifting) by `bit_offset` and take the `bit_size` least significant bits.
> >
> > For non-bitfields, `bit_offset` is zero and `bit_size` is equal to `byte_size * 8`.
>
> **`is_anonymous`**
>
> > True if this field is anonymous, that is, it contains nested sub-fields that should be merged into a containing structure or union.

### Arrays and pointers

**`class ctypes.Array(*args)`**

> Abstract base class for arrays.
>
> The recommended way to create concrete array types is by multiplying any `ctypes` data type with a non-negative integer. Alternatively, you can subclass this type and define [`_length_`](#ctypes.Array._length_ "ctypes.Array._length_") and [`_type_`](#ctypes.Array._type_ "ctypes.Array._type_") class variables. Array elements can be read and written using standard subscript and slice accesses; for slice reads, the resulting object is *not* itself an `Array`.
>
> Arrays are [generic](typing.md#generics) over the type of their elements.
>
> **`_length_`**
>
> > A positive integer specifying the number of elements in the array. Out-of-range subscripts result in an [`IndexError`](../builtins/exceptions.md#IndexError "IndexError"). Will be returned by [`len()`](../builtins/functions.md#len "len").
>
> **`_type_`**
>
> > Specifies the type of each element in the array.
>
> Array subclass constructors accept positional arguments, used to initialize the elements in order.

**`ctypes.ARRAY(type, length)`**

> Create an array. Equivalent to `type * length`, where *type* is a `ctypes` data type and *length* an integer.
>
> [Soft deprecated](https://docs.python.org/3.14/glossary.html#term-soft-deprecated) since version 3.14: In favor of multiplication.

**`class ctypes._Pointer`**

> Private, abstract base class for pointers.
>
> Concrete pointer types are created by calling [`POINTER()`](#ctypes.POINTER "ctypes.POINTER") with the type that will be pointed to; this is done automatically by [`pointer()`](#ctypes.pointer "ctypes.pointer").
>
> If a pointer points to an array, its elements can be read and written using standard subscript and slice accesses. Pointer objects have no size, so [`len()`](../builtins/functions.md#len "len") will raise [`TypeError`](../builtins/exceptions.md#TypeError "TypeError"). Negative subscripts will read from the memory *before* the pointer (as in C), and out-of-range subscripts will probably crash with an access violation (if you’re lucky).
>
> **`_type_`**
>
> > Specifies the type pointed to.
>
> **`contents`**
>
> > Returns the object to which to pointer points. Assigning to this attribute changes the pointer to point to the assigned object.

### Exceptions

**`exception ctypes.ArgumentError`**

> This exception is raised when a foreign function call cannot convert one of the passed arguments.

**`exception ctypes.COMError(hresult, text, details)`**

> This exception is raised when a COM method call failed.
>
> **`hresult`**
>
> > The integer value representing the error code.
>
> **`text`**
>
> > The error message.
>
> **`details`**
>
> > The 5-tuple `(descr, source, helpfile, helpcontext, progid)`.
> >
> > *descr* is the textual description. *source* is the language-dependent `ProgID` for the class or application that raised the error. *helpfile* is the path of the help file. *helpcontext* is the help context identifier. *progid* is the `ProgID` of the interface that defined the error.
>
> [Availability](intro.md#availability): Windows
>
> Added in version 3.14.
