---
title: "imghdr — Determine the type of an image"
source: https://docs.python.org/3.14/library/imghdr.html
---

# `imghdr` — Determine the type of an image

Deprecated since version 3.11, removed in version 3.13.

This module is no longer part of the Python standard library. It was [removed in Python 3.13](https://docs.python.org/3.14/whatsnew/3.13.html#whatsnew313-pep594) after being deprecated in Python 3.11. The removal was decided in [**PEP 594**](https://peps.python.org/pep-0594/).

Possible replacements are third-party libraries from PyPI: [filetype](https://pypi.org/project/filetype/), [puremagic](https://pypi.org/project/puremagic/), or [python-magic](https://pypi.org/project/python-magic/). These are not supported or maintained by the Python core team.

The last version of Python that provided the `imghdr` module was [Python 3.12](https://docs.python.org/3.12/library/imghdr.html).
