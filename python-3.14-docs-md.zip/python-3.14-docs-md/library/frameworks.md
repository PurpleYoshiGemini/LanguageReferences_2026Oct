---
title: "Program frameworks"
source: https://docs.python.org/3.14/library/frameworks.html
---

# Program frameworks

This chapter is no longer maintained, and the modules it contained have been moved to their respective topical documentation.

- [`cmd`](cmd.md#module-cmd "cmd: Build line-oriented command interpreters.") — [Command Line Interface Libraries](cmdlinelibs.md)

- [`shlex`](shlex.md#module-shlex "shlex: Simple lexical analysis for Unix shell-like languages.") — [Unix Specific Services](unix.md)

- [`turtle`](turtle.md#module-turtle "turtle: An educational framework for simple graphics applications") — [Graphical User Interfaces with Tk](tk.md)
