---
title: "tokenize — Tokenizer for Python source"
source: https://docs.python.org/3.14/library/tokenize.html
---

# `tokenize` — Tokenizer for Python source

**Source code:** [Lib/tokenize.py](https://github.com/python/cpython/tree/3.14/Lib/tokenize.py)

------------------------------------------------------------------------

The `tokenize` module provides a lexical scanner for Python source code, implemented in Python. The scanner in this module returns comments as tokens as well, making it useful for implementing “pretty-printers”, including colorizers for on-screen displays.

To simplify token stream handling, all [operator](../reference/lexical_analysis.md#operators) and [delimiter](../reference/lexical_analysis.md#delimiters) tokens and [`Ellipsis`](../builtins/constants.md#Ellipsis "Ellipsis") are returned using the generic [`OP`](token.md#token.OP "token.OP") token type. The [`TokenInfo.exact_type`](#tokenize.TokenInfo.exact_type "tokenize.TokenInfo.exact_type") property gives the exact token type.

> **Warning:**
>
> Note that the functions in this module are only designed to parse syntactically valid Python code (code that does not raise when parsed using [`ast.parse()`](ast.md#ast.parse "ast.parse")). The behavior of the functions in this module is **undefined** when providing invalid Python code and it can change at any point.

## Tokenizing Input

The primary entry point is a [generator](https://docs.python.org/3.14/glossary.html#term-generator):

**`tokenize.tokenize(readline)`**

> The `tokenize()` generator requires one argument, *readline*, which must be a callable object which provides the same interface as the [`io.IOBase.readline()`](io.md#io.IOBase.readline "io.IOBase.readline") method of file objects. Each call to the function should return one line of input as bytes.
>
> The generator produces [`TokenInfo`](#tokenize.TokenInfo "tokenize.TokenInfo") objects.
>
> Changed in version 3.1: Changed to yield [`TokenInfo`](#tokenize.TokenInfo "tokenize.TokenInfo") objects instead of plain tuples.
>
> `tokenize()` determines the source encoding of the file by looking for a UTF-8 BOM or encoding cookie, according to [**PEP 263**](https://peps.python.org/pep-0263/).

**`tokenize.generate_tokens(readline)`**

> Tokenize a source reading unicode strings instead of bytes.
>
> Like [`tokenize()`](#tokenize.tokenize "tokenize.tokenize"), the *readline* argument is a callable returning a single line of input. However, `generate_tokens()` expects *readline* to return a str object rather than bytes.
>
> The result is an iterator yielding [`TokenInfo`](#tokenize.TokenInfo "tokenize.TokenInfo") objects, exactly like [`tokenize()`](#tokenize.tokenize "tokenize.tokenize"). It does not yield an [`ENCODING`](token.md#token.ENCODING "token.ENCODING") token.

**`class tokenize.TokenInfo(type, string, start, end, line)`**

> A [named tuple](https://docs.python.org/3.14/glossary.html#term-named-tuple) describing a token. It has five fields and an additional [`exact_type`](#tokenize.TokenInfo.exact_type "tokenize.TokenInfo.exact_type") property.
>
> Added in version 3.1.
>
> **`type`**
>
> > An integer identifying the token type, as defined by the constants in [`token`](token.md#module-token "token: Constants representing terminal nodes of the parse tree."), such as [`NAME`](token.md#token.NAME "token.NAME") and [`STRING`](token.md#token.STRING "token.STRING"). Operators and delimiters have type [`OP`](token.md#token.OP "token.OP"); use [`exact_type`](#tokenize.TokenInfo.exact_type "tokenize.TokenInfo.exact_type") for their specific token type.
>
> **`string`**
>
> > The token text as a [`str`](../builtins/stdtypes.md#str "str"). For [`STRING`](token.md#token.STRING "token.STRING") tokens, this includes the quotes, any prefix, and escape sequences, without evaluating them.
> >
> > For an [`ENCODING`](token.md#token.ENCODING "token.ENCODING") token, this is the encoding name. Tokens inserted without corresponding source text can have an empty string. In [`FSTRING_MIDDLE`](token.md#token.FSTRING_MIDDLE "token.FSTRING_MIDDLE") and [`TSTRING_MIDDLE`](token.md#token.TSTRING_MIDDLE "token.TSTRING_MIDDLE") tokens, doubled braces are replaced by single braces.
>
> **`start`**
>
> > A 2-tuple `(srow, scol)` of ints specifying the inclusive start position of the token in the source. Rows are numbered from 1 and columns from 0. Columns count Unicode code points; a tab counts as one column, without expanding it to a tab stop.
> >
> > For an [`ENCODING`](token.md#token.ENCODING "token.ENCODING") token, this is `(0, 0)`.
>
> **`end`**
>
> > A 2-tuple `(erow, ecol)` of ints specifying the exclusive end position of the token. Rows are numbered from 1 and columns from 0. For a token spanning multiple lines, *erow* is the final row and *ecol* is the column on that row.
> >
> > For example, the name `spam` at the beginning of the first line has [`start`](#tokenize.TokenInfo.start "tokenize.TokenInfo.start") equal to `(1, 0)` and [`end`](#tokenize.TokenInfo.end "tokenize.TokenInfo.end") equal to `(1, 4)`.
> >
> > For an [`ENCODING`](token.md#token.ENCODING "token.ENCODING") token, this is `(0, 0)`. A [`NEWLINE`](token.md#token.NEWLINE "token.NEWLINE") or [`NL`](token.md#token.NL "token.NL") token inserted at the end of input without a final newline can have an end column one beyond the source text.
>
> **`line`**
>
> > A [`str`](../builtins/stdtypes.md#str "str") containing the full source line on which the token was found, including surrounding text and the line terminator if present. For a token spanning multiple lines, this can contain several source lines. It is empty for [`ENCODING`](token.md#token.ENCODING "token.ENCODING") and [`ENDMARKER`](token.md#token.ENDMARKER "token.ENDMARKER") tokens.
>
> **`exact_type`**
>
> > An integer identifying the specific operator type for [`OP`](token.md#token.OP "token.OP") tokens, as defined by the constants in [`token`](token.md#module-token "token: Constants representing terminal nodes of the parse tree."). For all other token types, this equals [`type`](../builtins/functions.md#type "type"). For example, a `+` token has `type` equal to `OP` and [`exact_type`](#tokenize.TokenInfo.exact_type "tokenize.TokenInfo.exact_type") equal to [`PLUS`](token.md#token.PLUS "token.PLUS").
> >
> > Added in version 3.3.

All constants from the [`token`](token.md#module-token "token: Constants representing terminal nodes of the parse tree.") module are also exported from `tokenize`.

Another function is provided to reverse the tokenization process. This is useful for creating tools that tokenize a script, modify the token stream, and write back the modified script.

**`tokenize.untokenize(iterable)`**

> Converts tokens back into Python source code. The *iterable* must return sequences with at least two elements, the token type and the token string. Any additional sequence elements are ignored.
>
> The result is guaranteed to tokenize back to match the input so that the conversion is lossless and round-trips are assured. The guarantee applies only to the token type and token string as the spacing between tokens (column positions) may change.
>
> It returns bytes, encoded using the [`ENCODING`](token.md#token.ENCODING "token.ENCODING") token, which is the first token sequence output by [`tokenize()`](#tokenize.tokenize "tokenize.tokenize"). If there is no encoding token in the input, it returns a str instead.

[`tokenize()`](#tokenize.tokenize "tokenize.tokenize") needs to detect the encoding of source files it tokenizes. The function it uses to do this is available:

**`tokenize.detect_encoding(readline)`**

> The `detect_encoding()` function is used to detect the encoding that should be used to decode a Python source file. It requires one argument, readline, in the same way as the [`tokenize()`](#tokenize.tokenize "tokenize.tokenize") generator.
>
> It will call readline a maximum of twice, and return the encoding used (as a string) and a list of any lines (not decoded from bytes) it has read in.
>
> It detects the encoding from the presence of a UTF-8 BOM or an encoding cookie as specified in [**PEP 263**](https://peps.python.org/pep-0263/). If both a BOM and a cookie are present, but disagree, a [`SyntaxError`](../builtins/exceptions.md#SyntaxError "SyntaxError") will be raised. Note that if the BOM is found, `'utf-8-sig'` will be returned as an encoding.
>
> If no encoding is specified, then the default of `'utf-8'` will be returned.
>
> Use [`open()`](#tokenize.open "tokenize.open") to open Python source files: it uses `detect_encoding()` to detect the file encoding.

**`tokenize.open(filename)`**

> Open a file in read only mode using the encoding detected by [`detect_encoding()`](#tokenize.detect_encoding "tokenize.detect_encoding").
>
> Added in version 3.2.

**`exception tokenize.TokenError`**

> Raised when either a docstring or expression that may be split over several lines is not completed anywhere in the file, for example:
>
> ``` python
> """Beginning of
> docstring
> ```
>
> or:
>
> ``` python
> [1,
>  2,
>  3
> ```

## Command-Line Usage

Added in version 3.3.

The `tokenize` module can be executed as a script from the command line. It is as simple as:

``` sh
python -m tokenize [-e] [filename.py]
```

The following options are accepted:

**`-h, --help`**

> show this help message and exit

**`-e, --exact`**

> display token names using the exact type

If `filename.py` is specified its contents are tokenized to stdout. Otherwise, tokenization is performed on stdin.

## Examples

Example of a script rewriter that transforms float literals into Decimal objects:

``` python
from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP
from io import BytesIO

def decistmt(s):
    """Substitute Decimals for floats in a string of statements.

    >>> from decimal import Decimal
    >>> s = 'print(+21.3e-5*-.1234/81.7)'
    >>> decistmt(s)
    "print (+Decimal ('21.3e-5')*-Decimal ('.1234')/Decimal ('81.7'))"

    The format of the exponent is inherited from the platform C library.
    Known cases are "e-007" (Windows) and "e-07" (not Windows).  Since
    we're only showing 12 digits, and the 13th isn't close to 5, the
    rest of the output should be platform-independent.

    >>> exec(s)  #doctest: +ELLIPSIS
    -3.21716034272e-0...7

    Output from calculations with Decimal should be identical across all
    platforms.

    >>> exec(decistmt(s))
    -3.217160342717258261933904529E-7
    """
    result = []
    g = tokenize(BytesIO(s.encode('utf-8')).readline)  # tokenize the string
    for toknum, tokval, _, _, _ in g:
        if toknum == NUMBER and '.' in tokval:  # replace NUMBER tokens
            result.extend([
                (NAME, 'Decimal'),
                (OP, '('),
                (STRING, repr(tokval)),
                (OP, ')')
            ])
        else:
            result.append((toknum, tokval))
    return untokenize(result).decode('utf-8')
```

Example of tokenizing from the command line. The script:

``` python
def say_hello():
    print("Hello, World!")

say_hello()
```

will be tokenized to the following output where the first column is the range of the line/column coordinates where the token is found, the second column is the name of the token, and the final column is the value of the token (if any)

``` console
$ python -m tokenize hello.py
0,0-0,0:            ENCODING       'utf-8'
1,0-1,3:            NAME           'def'
1,4-1,13:           NAME           'say_hello'
1,13-1,14:          OP             '('
1,14-1,15:          OP             ')'
1,15-1,16:          OP             ':'
1,16-1,17:          NEWLINE        '\n'
2,0-2,4:            INDENT         '    '
2,4-2,9:            NAME           'print'
2,9-2,10:           OP             '('
2,10-2,25:          STRING         '"Hello, World!"'
2,25-2,26:          OP             ')'
2,26-2,27:          NEWLINE        '\n'
3,0-3,1:            NL             '\n'
4,0-4,0:            DEDENT         ''
4,0-4,9:            NAME           'say_hello'
4,9-4,10:           OP             '('
4,10-4,11:          OP             ')'
4,11-4,12:          NEWLINE        '\n'
5,0-5,0:            ENDMARKER      ''
```

The exact token type names can be displayed using the [`-e`](#cmdoption-tokenize-e) option:

``` console
$ python -m tokenize -e hello.py
0,0-0,0:            ENCODING       'utf-8'
1,0-1,3:            NAME           'def'
1,4-1,13:           NAME           'say_hello'
1,13-1,14:          LPAR           '('
1,14-1,15:          RPAR           ')'
1,15-1,16:          COLON          ':'
1,16-1,17:          NEWLINE        '\n'
2,0-2,4:            INDENT         '    '
2,4-2,9:            NAME           'print'
2,9-2,10:           LPAR           '('
2,10-2,25:          STRING         '"Hello, World!"'
2,25-2,26:          RPAR           ')'
2,26-2,27:          NEWLINE        '\n'
3,0-3,1:            NL             '\n'
4,0-4,0:            DEDENT         ''
4,0-4,9:            NAME           'say_hello'
4,9-4,10:           LPAR           '('
4,10-4,11:          RPAR           ')'
4,11-4,12:          NEWLINE        '\n'
5,0-5,0:            ENDMARKER      ''
```

Example of tokenizing a file programmatically, reading unicode strings instead of bytes with [`generate_tokens()`](#tokenize.generate_tokens "tokenize.generate_tokens"):

``` python
import tokenize

with tokenize.open('hello.py') as f:
    tokens = tokenize.generate_tokens(f.readline)
    for token in tokens:
        print(token)
```

Or reading bytes directly with [`tokenize()`](#tokenize.tokenize "tokenize.tokenize"):

``` python
import tokenize

with open('hello.py', 'rb') as f:
    tokens = tokenize.tokenize(f.readline)
    for token in tokens:
        print(token)
```
