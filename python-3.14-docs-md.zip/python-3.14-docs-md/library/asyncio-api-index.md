---
title: "High-level API Index"
source: https://docs.python.org/3.14/library/asyncio-api-index.html
---

# High-level API Index

This page lists all high-level async/await enabled asyncio APIs.

## Tasks

Utilities to run asyncio programs, create Tasks, and await on multiple things with timeouts.

|  |  |
|---|---|
| [`run()`](asyncio-runner.html#asyncio.run "asyncio.run") | Create event loop, run a coroutine, close the loop. |
| [`Runner`](asyncio-runner.html#asyncio.Runner "asyncio.Runner") | A context manager that simplifies multiple async function calls. |
| [`Task`](asyncio-task.html#asyncio.Task "asyncio.Task") | Task object. |
| [`TaskGroup`](asyncio-task.html#asyncio.TaskGroup "asyncio.TaskGroup") | A context manager that holds a group of tasks. Provides a convenient and reliable way to wait for all tasks in the group to finish. |
| [`create_task()`](asyncio-task.html#asyncio.create_task "asyncio.create_task") | Start an asyncio Task, then returns it. |
| [`current_task()`](asyncio-task.html#asyncio.current_task "asyncio.current_task") | Return the current Task. |
| [`all_tasks()`](asyncio-task.html#asyncio.all_tasks "asyncio.all_tasks") | Return all tasks that are not yet finished for an event loop. |
| `await` [`sleep()`](asyncio-task.html#asyncio.sleep "asyncio.sleep") | Sleep for a number of seconds. |
| `await` [`gather()`](asyncio-task.html#asyncio.gather "asyncio.gather") | Schedule and wait for things concurrently. |
| `await` [`wait_for()`](asyncio-task.html#asyncio.wait_for "asyncio.wait_for") | Run with a timeout. |
| `await` [`shield()`](asyncio-task.html#asyncio.shield "asyncio.shield") | Shield from cancellation. |
| `await` [`wait()`](asyncio-task.html#asyncio.wait "asyncio.wait") | Monitor for completion. |
| [`timeout()`](asyncio-task.html#asyncio.timeout "asyncio.timeout") | Run with a timeout. Useful in cases when `wait_for` is not suitable. |
| [`to_thread()`](asyncio-task.html#asyncio.to_thread "asyncio.to_thread") | Asynchronously run a function in a separate OS thread. |
| [`run_coroutine_threadsafe()`](asyncio-task.html#asyncio.run_coroutine_threadsafe "asyncio.run_coroutine_threadsafe") | Schedule a coroutine from another OS thread. |
| `for`` ``in` [`as_completed()`](asyncio-task.html#asyncio.as_completed "asyncio.as_completed") | Monitor for completion with a `for` loop. |

Examples

- [Using asyncio.gather() to run things in parallel](asyncio-task.md#asyncio-example-gather).

- [Using asyncio.wait_for() to enforce a timeout](asyncio-task.md#asyncio-example-waitfor).

- [Cancellation](asyncio-task.md#asyncio-example-task-cancel).

- [Using asyncio.sleep()](asyncio-task.md#asyncio-example-sleep).

- See also the main [Tasks documentation page](asyncio-task.md#coroutine).

## Queues

Queues should be used to distribute work amongst multiple asyncio Tasks, implement connection pools, and pub/sub patterns.

|  |  |
|---|---|
| [`Queue`](asyncio-queue.html#asyncio.Queue "asyncio.Queue") | A FIFO queue. |
| [`PriorityQueue`](asyncio-queue.html#asyncio.PriorityQueue "asyncio.PriorityQueue") | A priority queue. |
| [`LifoQueue`](asyncio-queue.html#asyncio.LifoQueue "asyncio.LifoQueue") | A LIFO queue. |

Examples

- [Using asyncio.Queue to distribute workload between several Tasks](asyncio-queue.md#asyncio-example-queue-dist).

- See also the [Queues documentation page](asyncio-queue.md#asyncio-queues).

## Subprocesses

Utilities to spawn subprocesses and run shell commands.

|  |  |
|---|---|
| `await` [`create_subprocess_exec()`](asyncio-subprocess.html#asyncio.create_subprocess_exec "asyncio.create_subprocess_exec") | Create a subprocess. |
| `await` [`create_subprocess_shell()`](asyncio-subprocess.html#asyncio.create_subprocess_shell "asyncio.create_subprocess_shell") | Run a shell command. |

Examples

- [Executing a shell command](asyncio-subprocess.md#asyncio-example-subprocess-shell).

- See also the [subprocess APIs](asyncio-subprocess.md#asyncio-subprocess) documentation.

## Streams

High-level APIs to work with network IO.

|  |  |
|---|---|
| `await` [`open_connection()`](asyncio-stream.html#asyncio.open_connection "asyncio.open_connection") | Establish a TCP connection. |
| `await` [`open_unix_connection()`](asyncio-stream.html#asyncio.open_unix_connection "asyncio.open_unix_connection") | Establish a Unix socket connection. |
| `await` [`start_server()`](asyncio-stream.html#asyncio.start_server "asyncio.start_server") | Start a TCP server. |
| `await` [`start_unix_server()`](asyncio-stream.html#asyncio.start_unix_server "asyncio.start_unix_server") | Start a Unix socket server. |
| [`StreamReader`](asyncio-stream.html#asyncio.StreamReader "asyncio.StreamReader") | High-level async/await object to receive network data. |
| [`StreamWriter`](asyncio-stream.html#asyncio.StreamWriter "asyncio.StreamWriter") | High-level async/await object to send network data. |

Examples

- [Example TCP client](asyncio-stream.md#asyncio-example-stream).

- See also the [streams APIs](asyncio-stream.md#asyncio-streams) documentation.

## Synchronization

Threading-like synchronization primitives that can be used in Tasks.

|  |  |
|---|---|
| [`Lock`](asyncio-sync.html#asyncio.Lock "asyncio.Lock") | A mutex lock. |
| [`Event`](asyncio-sync.html#asyncio.Event "asyncio.Event") | An event object. |
| [`Condition`](asyncio-sync.html#asyncio.Condition "asyncio.Condition") | A condition object. |
| [`Semaphore`](asyncio-sync.html#asyncio.Semaphore "asyncio.Semaphore") | A semaphore. |
| [`BoundedSemaphore`](asyncio-sync.html#asyncio.BoundedSemaphore "asyncio.BoundedSemaphore") | A bounded semaphore. |
| [`Barrier`](asyncio-sync.html#asyncio.Barrier "asyncio.Barrier") | A barrier object. |

Examples

- [Using asyncio.Event](asyncio-sync.md#asyncio-example-sync-event).

- [Using asyncio.Barrier](asyncio-sync.md#asyncio-example-barrier).

- See also the documentation of asyncio [synchronization primitives](asyncio-sync.md#asyncio-sync).

## Exceptions

|  |  |
|---|---|
| [`asyncio.CancelledError`](asyncio-exceptions.html#asyncio.CancelledError "asyncio.CancelledError") | Raised when a Task is cancelled. See also [`Task.cancel()`](asyncio-task.html#asyncio.Task.cancel "asyncio.Task.cancel"). |
| [`asyncio.BrokenBarrierError`](asyncio-sync.html#asyncio.BrokenBarrierError "asyncio.BrokenBarrierError") | Raised when a Barrier is broken. See also [`Barrier.wait()`](asyncio-sync.html#asyncio.Barrier.wait "asyncio.Barrier.wait"). |

Examples

- [Handling CancelledError to run code on cancellation request](asyncio-task.md#asyncio-example-task-cancel).

- See also the full list of [asyncio-specific exceptions](asyncio-exceptions.md#asyncio-exceptions).
