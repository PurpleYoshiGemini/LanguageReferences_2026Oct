---
title: "Exceptions"
source: https://docs.python.org/3.14/library/asyncio-exceptions.html
---

# Exceptions

**Source code:** [Lib/asyncio/exceptions.py](https://github.com/python/cpython/tree/3.14/Lib/asyncio/exceptions.py)

------------------------------------------------------------------------

**`exception asyncio.TimeoutError`**

> A deprecated alias of `TimeoutError`, raised when the operation has exceeded the given deadline.
>
> Changed in version 3.11: This class was made an alias of `TimeoutError`.

**`exception asyncio.CancelledError`**

> The operation has been cancelled.
>
> This exception can be caught to perform custom operations when asyncio Tasks are cancelled. In almost all situations the exception must be re-raised.
>
> Changed in version 3.8: `CancelledError` is now a subclass of [`BaseException`](../builtins/exceptions.md#BaseException "BaseException") rather than [`Exception`](../builtins/exceptions.md#Exception "Exception").

**`exception asyncio.InvalidStateError`**

> Invalid internal state of [`Task`](asyncio-task.md#asyncio.Task "asyncio.Task") or [`Future`](asyncio-future.md#asyncio.Future "asyncio.Future").
>
> Can be raised in situations like setting a result value for a *Future* object that already has a result value set.

**`exception asyncio.SendfileNotAvailableError`**

> The “sendfile” syscall is not available for the given socket or file type.
>
> A subclass of [`RuntimeError`](../builtins/exceptions.md#RuntimeError "RuntimeError").

**`exception asyncio.IncompleteReadError`**

> The requested read operation did not complete fully.
>
> Raised by the [asyncio stream APIs](asyncio-stream.md#asyncio-streams).
>
> This exception is a subclass of [`EOFError`](../builtins/exceptions.md#EOFError "EOFError").
>
> **`expected`**
>
> > The total number ([`int`](../builtins/functions.md#int "int")) of expected bytes.
>
> **`partial`**
>
> > A string of [`bytes`](../builtins/stdtypes.md#bytes "bytes") read before the end of stream was reached.

**`exception asyncio.LimitOverrunError`**

> Reached the buffer size limit while looking for a separator.
>
> Raised by the [asyncio stream APIs](asyncio-stream.md#asyncio-streams).
>
> **`consumed`**
>
> > The total number of to be consumed bytes.
