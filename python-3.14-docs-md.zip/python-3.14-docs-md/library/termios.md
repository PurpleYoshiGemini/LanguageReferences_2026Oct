---
title: "termios — POSIX style tty control"
source: https://docs.python.org/3.14/library/termios.html
---

# `termios` — POSIX style tty control

------------------------------------------------------------------------

This module provides an interface to the POSIX calls for tty I/O control. For a complete description of these calls, see *[termios(3)](https://manpages.debian.org/termios(3))* Unix manual page. It is only available for those Unix versions that support POSIX *termios* style tty I/O control configured during installation.

[Availability](intro.md#availability): Unix.

All functions in this module take a file descriptor *fd* as their first argument. This can be an integer file descriptor, such as returned by `sys.stdin.fileno()`, or a [file object](https://docs.python.org/3.14/glossary.html#term-file-object), such as `sys.stdin` itself.

This module also defines all the constants needed to work with the functions provided here; these have the same name as their counterparts in C. Please refer to your system documentation for more information on using these terminal control interfaces.

The module defines the following functions:

**`termios.tcgetattr(fd)`**

> Return a list containing the tty attributes for file descriptor *fd*, as follows: `[iflag, oflag, cflag, lflag, ispeed, ospeed, cc]` where *cc* is a list of the tty special characters (each a string of length 1, except the items with indices [`VMIN`](#termios.VMIN "termios.VMIN") and [`VTIME`](#termios.VTIME "termios.VTIME"), which are integers when these fields are defined). The interpretation of the flags and the speeds as well as the indexing in the *cc* array must be done using the symbolic constants defined in the `termios` module.
>
> **`termios.VMIN`**
>
> **`termios.VTIME`**
>
> > Indices into the *cc* array controlling a non-canonical read: the minimum number of characters to read and the timeout in tenths of a second, respectively.

**`termios.tcsetattr(fd, when, attributes)`**

> Set the tty attributes for file descriptor *fd* from the *attributes*, which is a list like the one returned by [`tcgetattr()`](#termios.tcgetattr "termios.tcgetattr"). The *when* argument determines when the attributes are changed:
>
> **`termios.TCSANOW`**
>
> > Change attributes immediately.
>
> **`termios.TCSADRAIN`**
>
> > Change attributes after transmitting all queued output.
>
> **`termios.TCSAFLUSH`**
>
> > Change attributes after transmitting all queued output and discarding all queued input.

**`termios.tcsendbreak(fd, duration)`**

> Send a break on file descriptor *fd*. A zero *duration* sends a break for 0.25–0.5 seconds; a nonzero *duration* has a system dependent meaning.

**`termios.tcdrain(fd)`**

> Wait until all output written to file descriptor *fd* has been transmitted.

**`termios.tcflush(fd, queue)`**

> Discard queued data on file descriptor *fd*. The *queue* selector specifies which queue: [`TCIFLUSH`](#termios.TCIFLUSH "termios.TCIFLUSH") for the input queue, [`TCOFLUSH`](#termios.TCOFLUSH "termios.TCOFLUSH") for the output queue, or [`TCIOFLUSH`](#termios.TCIOFLUSH "termios.TCIOFLUSH") for both queues.
>
> **`termios.TCIFLUSH`**
>
> **`termios.TCOFLUSH`**
>
> **`termios.TCIOFLUSH`**
>
> > Values for the *queue* selector: the input queue, the output queue, or both queues, respectively.

**`termios.tcflow(fd, action)`**

> Suspend or resume input or output on file descriptor *fd*. The *action* argument can be [`TCOOFF`](#termios.TCOOFF "termios.TCOOFF") to suspend output, [`TCOON`](#termios.TCOON "termios.TCOON") to restart output, [`TCIOFF`](#termios.TCIOFF "termios.TCIOFF") to suspend input, or [`TCION`](#termios.TCION "termios.TCION") to restart input.
>
> **`termios.TCOOFF`**
>
> **`termios.TCOON`**
>
> **`termios.TCIOFF`**
>
> **`termios.TCION`**
>
> > Values for the *action* argument: suspend output, restart output, suspend input, or restart input, respectively.

**`termios.tcgetwinsize(fd)`**

> Return a tuple `(ws_row, ws_col)` containing the tty window size for file descriptor *fd*. Requires [`termios.TIOCGWINSZ`](#termios.TIOCGWINSZ "termios.TIOCGWINSZ") or [`termios.TIOCGSIZE`](#termios.TIOCGSIZE "termios.TIOCGSIZE").
>
> Added in version 3.11.
>
> **`termios.TIOCGWINSZ`**
>
> **`termios.TIOCGSIZE`**
>
> > `ioctl()` requests for querying the tty window size. Not defined on all platforms; `tcgetwinsize()` requires at least one of them.

**`termios.tcsetwinsize(fd, winsize)`**

> Set the tty window size for file descriptor *fd* from *winsize*, which is a two-item tuple `(ws_row, ws_col)` like the one returned by [`tcgetwinsize()`](#termios.tcgetwinsize "termios.tcgetwinsize"). Requires at least one of the pairs ([`termios.TIOCGWINSZ`](#termios.TIOCGWINSZ "termios.TIOCGWINSZ"), [`termios.TIOCSWINSZ`](#termios.TIOCSWINSZ "termios.TIOCSWINSZ")); ([`termios.TIOCGSIZE`](#termios.TIOCGSIZE "termios.TIOCGSIZE"), [`termios.TIOCSSIZE`](#termios.TIOCSSIZE "termios.TIOCSSIZE")) to be defined.
>
> Added in version 3.11.
>
> **`termios.TIOCSWINSZ`**
>
> **`termios.TIOCSSIZE`**
>
> > `ioctl()` requests for setting the tty window size. Not defined on all platforms; see `tcsetwinsize()` for the required pairs.

> **See also:**
>
> Module [`tty`](tty.md#module-tty "tty: Utility functions that perform common terminal control operations.")  
> Convenience functions for common terminal control operations.

## Example

Here’s a function that prompts for a password with echoing turned off. Note the technique using a separate [`tcgetattr()`](#termios.tcgetattr "termios.tcgetattr") call and a [`try`](../reference/compound_stmts.md#try) … [`finally`](../reference/compound_stmts.md#finally) statement to ensure that the old tty attributes are restored exactly no matter what happens:

``` python
def getpass(prompt="Password: "):
    import termios, sys
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    new = termios.tcgetattr(fd)
    new[3] = new[3] & ~termios.ECHO          # lflags
    try:
        termios.tcsetattr(fd, termios.TCSADRAIN, new)
        passwd = input(prompt)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
    return passwd
```
