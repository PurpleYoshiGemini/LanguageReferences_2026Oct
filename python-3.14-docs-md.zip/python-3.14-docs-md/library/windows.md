---
title: "MS Windows Specific Services"
source: https://docs.python.org/3.14/library/windows.html
---

# MS Windows Specific Services

This chapter describes modules that are only available on MS Windows platforms.

- [`msvcrt` — Useful routines from the MS VC++ runtime](msvcrt.md)
  - [File Operations](msvcrt.md#file-operations)
  - [Console I/O](msvcrt.md#console-i-o)
  - [Other Functions](msvcrt.md#other-functions)
- [`winreg` — Windows registry access](winreg.md)
  - [Functions](winreg.md#functions)
  - [Constants](winreg.md#constants)
    - [HKEY_* Constants](winreg.md#hkey-constants)
    - [Access Rights](winreg.md#access-rights)
      - [64-bit Specific](winreg.md#bit-specific)
    - [Value Types](winreg.md#value-types)
  - [Registry Handle Objects](winreg.md#registry-handle-objects)
- [`winsound` — Sound-playing interface for Windows](winsound.md)
