---
title: "The concurrent package"
source: https://docs.python.org/3.14/library/concurrent.html
---

# The `concurrent` package

This package contains the following modules:

- [`concurrent.futures`](concurrent.futures.md#module-concurrent.futures "concurrent.futures: Execute computations concurrently using threads or processes.") – Launching parallel tasks

- [`concurrent.interpreters`](concurrent.interpreters.md#module-concurrent.interpreters "concurrent.interpreters: Multiple interpreters in the same process") – Multiple interpreters in the same process
