---
title: "The compression package"
source: https://docs.python.org/3.14/library/compression.html
---

# The `compression` package

Added in version 3.14.

The `compression` package contains the canonical compression modules containing interfaces to several different compression algorithms. Some of these modules have historically been available as separate modules; those will continue to be available under their original names for compatibility reasons, and will not be removed without a deprecation cycle. The use of modules in `compression` is encouraged where practical.

- `compression.bz2` – Re-exports [`bz2`](bz2.md#module-bz2 "bz2: Interfaces for bzip2 compression and decompression.")

- `compression.gzip` – Re-exports [`gzip`](gzip.md#module-gzip "gzip: Interfaces for gzip compression and decompression using file objects.")

- `compression.lzma` – Re-exports [`lzma`](lzma.md#module-lzma "lzma: A Python wrapper for the liblzma compression library.")

- `compression.zlib` – Re-exports [`zlib`](zlib.md#module-zlib "zlib: Low-level interface to compression and decompression routines compatible with gzip.")

- [`compression.zstd`](compression.zstd.md#module-compression.zstd "compression.zstd: Low-level interface to compression and decompression routines in the zstd library.") – Wrapper for the Zstandard compression library
