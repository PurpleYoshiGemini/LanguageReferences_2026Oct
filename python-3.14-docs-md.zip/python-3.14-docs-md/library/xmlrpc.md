---
title: "xmlrpc — XMLRPC server and client modules"
source: https://docs.python.org/3.14/library/xmlrpc.html
---

# `xmlrpc` — XMLRPC server and client modules

XML-RPC is a Remote Procedure Call method that uses XML passed via HTTP as a transport. With it, a client can call methods with parameters on a remote server (the server is named by a URI) and get back structured data.

`xmlrpc` is a package that collects server and client modules implementing XML-RPC. The modules are:

- [`xmlrpc.client`](xmlrpc.client.md#module-xmlrpc.client "xmlrpc.client: XML-RPC client access.")

- [`xmlrpc.server`](xmlrpc.server.md#module-xmlrpc.server "xmlrpc.server: Basic XML-RPC server implementations.")
