---
title: "chunk — Read IFF chunked data"
source: https://docs.python.org/3.14/library/chunk.html
---

# `chunk` — Read IFF chunked data

Deprecated since version 3.11, removed in version 3.13.

This module is no longer part of the Python standard library. It was [removed in Python 3.13](https://docs.python.org/3.14/whatsnew/3.13.html#whatsnew313-pep594) after being deprecated in Python 3.11. The removal was decided in [**PEP 594**](https://peps.python.org/pep-0594/).

The last version of Python that provided the `chunk` module was [Python 3.12](https://docs.python.org/3.12/library/chunk.html).
