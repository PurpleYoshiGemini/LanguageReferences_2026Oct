---
title: "Multimedia Services"
source: https://docs.python.org/3.14/library/mm.html
---

# Multimedia Services

The modules described in this chapter implement various algorithms or interfaces that are mainly useful for multimedia applications. They are available at the discretion of the installation. Here’s an overview:

- [`wave` — Read and write WAV files](wave.md)
  - [Wave_read Objects](wave.md#wave-read-objects)
  - [Wave_write Objects](wave.md#wave-write-objects)
- [`colorsys` — Conversions between color systems](colorsys.md)
