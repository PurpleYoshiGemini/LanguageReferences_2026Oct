---
title: "keyword — Testing for Python keywords"
source: https://docs.python.org/3.14/library/keyword.html
---

# `keyword` — Testing for Python keywords

**Source code:** [Lib/keyword.py](https://github.com/python/cpython/tree/3.14/Lib/keyword.py)

------------------------------------------------------------------------

This module allows a Python program to determine if a string is a [keyword](../reference/lexical_analysis.md#keywords) or [soft keyword](../reference/lexical_analysis.md#soft-keywords).

**`keyword.iskeyword(s)`**

> Return `True` if *s* is a Python [keyword](../reference/lexical_analysis.md#keywords).

**`keyword.kwlist`**

> Sequence containing all the [keywords](../reference/lexical_analysis.md#keywords) defined for the interpreter. If any keywords are defined to only be active when particular [`__future__`](__future__.md#module-__future__ "__future__: Future statement definitions") statements are in effect, these will be included as well.

**`keyword.issoftkeyword(s)`**

> Return `True` if *s* is a Python [soft keyword](../reference/lexical_analysis.md#soft-keywords).
>
> Added in version 3.9.

**`keyword.softkwlist`**

> Sequence containing all the [soft keywords](../reference/lexical_analysis.md#soft-keywords) defined for the interpreter. If any soft keywords are defined to only be active when particular [`__future__`](__future__.md#module-__future__ "__future__: Future statement definitions") statements are in effect, these will be included as well.
>
> Added in version 3.9.
