---
title: "Modules command-line interface (CLI)"
source: https://docs.python.org/3.14/library/cmdline.html
---

# Modules command-line interface (CLI)

The following modules have a command-line interface.

- [ast](ast.md#ast-cli)

- [asyncio](asyncio.md#asyncio-cli)

- [`base64`](base64.md#module-base64 "base64: RFC 4648: Base16, Base32, Base64 Data Encodings; Base85 and Ascii85")

- [calendar](calendar.md#calendar-cli)

- [`code`](code.md#module-code "code: Facilities to implement read-eval-print loops.")

- [compileall](compileall.md#compileall-cli)

- [`cProfile`](profile.md#module-cProfile "cProfile"): see [profile](profile.md#profile-cli)

- [dis](dis.md#dis-cli)

- [doctest](doctest.md#doctest-cli)

- `encodings.rot_13`

- [ensurepip](ensurepip.md#ensurepip-cli)

- [`filecmp`](filecmp.md#module-filecmp "filecmp: Compare files efficiently.")

- [`fileinput`](fileinput.md#module-fileinput "fileinput: Loop over standard input or a list of files.")

- [`ftplib`](ftplib.md#module-ftplib "ftplib: FTP protocol client (requires sockets).")

- [gzip](gzip.md#gzip-cli)

- [http.server](http.server.md#http-server-cli)

- [idlelib](idle.md#idlelib-cli)

- [inspect](inspect.md#inspect-module-cli)

- [json](json.md#json-commandline)

- [mimetypes](mimetypes.md#mimetypes-cli)

- [pdb](pdb.md#pdb-cli)

- [pickle](pickle.md#pickle-cli)

- [pickletools](pickletools.md#pickletools-cli)

- [platform](platform.md#platform-cli)

- [`poplib`](poplib.md#module-poplib "poplib: POP3 protocol client (requires sockets).")

- [profile](profile.md#profile-cli)

- [`pstats`](profile.md#module-pstats "pstats: Statistics object for use with the profiler.")

- [py_compile](py_compile.md#py-compile-cli)

- [`pyclbr`](pyclbr.md#module-pyclbr "pyclbr: Supports information extraction for a Python module browser.")

- [`pydoc`](pydoc.md#module-pydoc "pydoc: Documentation generator and online help system.")

- [`quopri`](quopri.md#module-quopri "quopri: Encode and decode files using the MIME quoted-printable encoding.")

- [random](random.md#random-cli)

- [`runpy`](runpy.md#module-runpy "runpy: Locate and run Python modules without importing them first.")

- [site](site.md#site-commandline)

- [sqlite3](sqlite3.md#sqlite3-cli)

- [symtable](symtable.md#symtable-cli)

- [sysconfig](sysconfig.md#sysconfig-cli)

- [`tabnanny`](tabnanny.md#module-tabnanny "tabnanny: Tool for detecting white space related problems in Python source files in a directory tree.")

- [tarfile](tarfile.md#tarfile-commandline)

- `this`

- [timeit](timeit.md#timeit-command-line-interface)

- [tokenize](tokenize.md#tokenize-cli)

- [trace](trace.md#trace-cli)

- [`turtledemo`](turtle.md#module-turtledemo "turtledemo: A viewer for example turtle scripts")

- [unittest](unittest.md#unittest-command-line-interface)

- [uuid](uuid.md#uuid-cli)

- [venv](venv.md#venv-cli)

- [webbrowser](webbrowser.md#webbrowser-cli)

- [zipapp](zipapp.md#zipapp-command-line-interface)

- [zipfile](zipfile.md#zipfile-commandline)

See also the [Python command-line interface](https://docs.python.org/3.14/using/cmdline.html#using-on-general).
