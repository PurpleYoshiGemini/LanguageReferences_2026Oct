---
title: "xml.dom.pulldom — Support for building partial DOM trees"
source: https://docs.python.org/3.14/library/xml.dom.pulldom.html
---

# `xml.dom.pulldom` — Support for building partial DOM trees

**Source code:** [Lib/xml/dom/pulldom.py](https://github.com/python/cpython/tree/3.14/Lib/xml/dom/pulldom.py)

------------------------------------------------------------------------

The `xml.dom.pulldom` module provides a “pull parser” which can also be asked to produce DOM-accessible fragments of the document where necessary. The basic concept involves pulling “events” from a stream of incoming XML and processing them. In contrast to SAX which also employs an event-driven processing model together with callbacks, the user of a pull parser is responsible for explicitly pulling events from the stream, looping over those events until either processing is finished or an error condition occurs.

> **Note:**
>
> If you need to parse untrusted or unauthenticated data, see [XML security](xml.md#xml-security).

Changed in version 3.7.1: The SAX parser no longer processes general external entities by default to increase security by default. To enable processing of external entities, pass a custom parser instance in:

``` python
from xml.dom.pulldom import parse
from xml.sax import make_parser
from xml.sax.handler import feature_external_ges

parser = make_parser()
parser.setFeature(feature_external_ges, True)
parse(filename, parser=parser)
```

Example:

``` python
from xml.dom import pulldom

doc = pulldom.parse('sales_items.xml')
for event, node in doc:
    if event == pulldom.START_ELEMENT and node.tagName == 'item':
        if int(node.getAttribute('price')) > 50:
            doc.expandNode(node)
            print(node.toxml())
```

`event` is one of the following constants, and `node` is the node which the event is about. The nodes implement the [`xml.dom`](xml.dom.md#module-xml.dom "xml.dom: Document Object Model API for Python.") interfaces; they are created by the DOM implementation given to [`PullDOM`](#xml.dom.pulldom.PullDOM "xml.dom.pulldom.PullDOM"), which is [`xml.dom.minidom`](xml.dom.minidom.md#module-xml.dom.minidom "xml.dom.minidom: Minimal Document Object Model (DOM) implementation.") by default.

**`xml.dom.pulldom.START_DOCUMENT`**

**`xml.dom.pulldom.END_DOCUMENT`**

> The start and the end of the document. *node* is the [`Document`](xml.dom.md#xml.dom.Document "xml.dom.Document").

**`xml.dom.pulldom.START_ELEMENT`**

**`xml.dom.pulldom.END_ELEMENT`**

> The start tag and the end tag of an element. *node* is the [`Element`](xml.dom.md#xml.dom.Element "xml.dom.Element").

**`xml.dom.pulldom.CHARACTERS`**

> Character data. *node* is the [`Text`](xml.dom.md#xml.dom.Text "xml.dom.Text") node.

**`xml.dom.pulldom.IGNORABLE_WHITESPACE`**

> White space in element content, as declared in the DTD. *node* is the [`Text`](xml.dom.md#xml.dom.Text "xml.dom.Text") node.

**`xml.dom.pulldom.COMMENT`**

> A comment. *node* is the [`Comment`](xml.dom.md#xml.dom.Comment "xml.dom.Comment") node.

**`xml.dom.pulldom.PROCESSING_INSTRUCTION`**

> A processing instruction. *node* is the [`ProcessingInstruction`](xml.dom.md#xml.dom.ProcessingInstruction "xml.dom.ProcessingInstruction") node.

Since the document is treated as a “flat” stream of events, the document “tree” is implicitly traversed and the desired elements are found regardless of their depth in the tree. In other words, one does not need to consider hierarchical issues such as recursive searching of the document nodes, although if the context of elements were important, one would either need to maintain some context-related state (i.e. remembering where one is in the document at any given point) or to make use of the [`DOMEventStream.expandNode()`](#xml.dom.pulldom.DOMEventStream.expandNode "xml.dom.pulldom.DOMEventStream.expandNode") method and switch to DOM-related processing.

**`class xml.dom.pulldom.PullDOM(documentFactory=None)`**

> Subclass of [`xml.sax.handler.ContentHandler`](xml.sax.handler.md#xml.sax.handler.ContentHandler "xml.sax.handler.ContentHandler") which turns SAX events into the events of the pull parser. The nodes are created, but they are not added to the tree, unless [`expandNode()`](#xml.dom.pulldom.DOMEventStream.expandNode "xml.dom.pulldom.DOMEventStream.expandNode") is called. *documentFactory*, if given, is a DOM implementation used to create the document; by default the implementation of [`xml.dom.minidom`](xml.dom.minidom.md#module-xml.dom.minidom "xml.dom.minidom: Minimal Document Object Model (DOM) implementation.") is used.

**`class xml.dom.pulldom.SAX2DOM(documentFactory=None)`**

> Subclass of [`PullDOM`](#xml.dom.pulldom.PullDOM "xml.dom.pulldom.PullDOM") which also adds every created node to the tree, so that the complete document is built.

**`xml.dom.pulldom.parse(stream_or_string, parser=None, bufsize=None)`**

> Return a [`DOMEventStream`](#xml.dom.pulldom.DOMEventStream "xml.dom.pulldom.DOMEventStream") from the given input. *stream_or_string* may be either a file name, or a file-like object. *parser*, if given, must be an [`XMLReader`](xml.sax.reader.md#xml.sax.xmlreader.XMLReader "xml.sax.xmlreader.XMLReader") object. This function will change the document handler of the parser and activate namespace support; other parser configuration (like setting an entity resolver) must have been done in advance.

If you have XML in a string, you can use the [`parseString()`](#xml.dom.pulldom.parseString "xml.dom.pulldom.parseString") function instead:

**`xml.dom.pulldom.parseString(string, parser=None)`**

> Return a [`DOMEventStream`](#xml.dom.pulldom.DOMEventStream "xml.dom.pulldom.DOMEventStream") that represents the *string*. *string* must be a [`str`](../builtins/stdtypes.md#str "str") instance; to parse bytes, pass a binary file object to [`parse()`](#xml.dom.pulldom.parse "xml.dom.pulldom.parse").

**`xml.dom.pulldom.default_bufsize`**

> Default value for the *bufsize* parameter to [`parse()`](#xml.dom.pulldom.parse "xml.dom.pulldom.parse").
>
> The value of this variable can be changed before calling [`parse()`](#xml.dom.pulldom.parse "xml.dom.pulldom.parse") and the new value will take effect.

## DOMEventStream Objects

**`class xml.dom.pulldom.DOMEventStream(stream, parser, bufsize)`**

> Produce the events for the data read from the file object *stream* by the [`XMLReader`](xml.sax.reader.md#xml.sax.xmlreader.XMLReader "xml.sax.xmlreader.XMLReader") *parser*. The data is read by *bufsize* bytes, or characters for a text stream, at a time.
>
> Changed in version 3.11: Support for [`__getitem__()`](../reference/datamodel.md#object.__getitem__ "object.__getitem__") method has been removed.
>
> **`getEvent()`**
>
> > Return the next `(event, node)` tuple, or `None` at the end of the document. See above for the events and the corresponding nodes. The current node does not contain information about its children, unless [`expandNode()`](#xml.dom.pulldom.DOMEventStream.expandNode "xml.dom.pulldom.DOMEventStream.expandNode") is called.
>
> **`expandNode(node)`**
>
> > Expands all children of *node* into *node*. Example:
> >
> > ``` python
> > from xml.dom import pulldom
> >
> > xml = '<html><title>Foo</title> <p>Some text <div>and more</div></p> </html>'
> > doc = pulldom.parseString(xml)
> > for event, node in doc:
> >     if event == pulldom.START_ELEMENT and node.tagName == 'p':
> >         # Following statement only prints '<p/>'
> >         print(node.toxml())
> >         doc.expandNode(node)
> >         # Following statement prints node with all its children '<p>Some text <div>and more</div></p>'
> >         print(node.toxml())
> > ```
>
> **`reset()`**
>
> > Discard the events which are not read yet and prepare the object for parsing a new document.
>
> **`clear()`**
>
> > Release the parser and the document. The stream is not closed, and the object can no longer be used.
