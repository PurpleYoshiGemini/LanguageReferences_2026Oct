---
title: "YAML Specification 1.2.2 Errata"
source: https://yaml.org/spec/1.2.2/ext/errata
---

# YAML Specification 1.2.2 Errata

- None yet reported
