# YAML Ain't Markup Language (YAML™) revision 1.2.2 — Markdown

Converted from https://yaml.org/spec/1.2.2/ (fetched 2026-10-31). Each file starts with front matter giving its title and source URL.

| File | Page |
|---|---|
| [index.md](index.md) | YAML Ain't Markup Language (YAML™) version 1.2, revision 1.2.2 (the full specification) |
| [ext/changes.md](ext/changes.md) | Changes from 1.2.1 to 1.2.2 |
| [ext/errata.md](ext/errata.md) | Errata |
| [ext/glossary.md](ext/glossary.md) | YAML Vocabulary Glossary |
| [ext/resources.md](ext/resources.md) | Resources |
| [ext/team.md](ext/team.md) | YAML Language Development Team |
| `img/*.svg` | The 7 diagrams referenced from index.md |

Notes: grammar productions are plain fenced blocks; side-by-side examples (YAML / JSON) are rendered as two consecutive fenced blocks; footnotes use GFM `[^id]` syntax; HTML `id` anchors from the site are preserved as `<a id="…"></a>` so all in-page links resolve.
